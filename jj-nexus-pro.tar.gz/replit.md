# JJ Nexus Pro

Elite Forex live streaming + AI trading command center for JJ Trades.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — API server (port 8080)
- `pnpm --filter @workspace/ethiostream-pro run dev` — Frontend (Vite dev server)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + Framer Motion
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- AI: Anthropic Claude (claude-sonnet-4-6) with web_search_20250305 tool
- Streaming: Real WebRTC via browser APIs (getUserMedia, MediaRecorder)

## Where things live

- `artifacts/ethiostream-pro/` — React frontend (Vite)
- `artifacts/api-server/src/routes/` — Express API routes:
  - `analysis/` — Forex analysis, confluence, news (with web search)
  - `anthropic/` — Alchemist AI chat (persistent conversations in DB)
  - `journal/` — Trade journal CRUD
  - `proxy/` — Backend proxy for external APIs (calendar, forex rates)
- `artifacts/ethiostream-pro/src/pages/` — App pages (Dashboard, Studio, AlchemistAI, Watchlist, Journal, EconomicCalendar, Settings)
- `lib/db/` — PostgreSQL schema + Drizzle ORM
- `lib/api-zod/` — Zod validation schemas (generated from OpenAPI)

## Architecture decisions

- Web_search enabled via `anthropic-beta: web-search-2025-03-05` header on the Anthropic SDK client (works with both Replit integration and direct API key)
- All external APIs (ForexFactory calendar, Frankfurter forex rates) proxied through `/api/proxy/*` backend routes to avoid browser CORS restrictions
- Background music uses HTML audio with Web Audio API fallback (ambient oscillators if CDN fails)
- XAUUSD base price: $4720 (May 2026 gold price — AI uses web_search to fetch current price)

## Product

- 📡 **Streaming Studio** — Real WebRTC camera/screen share, local .webm recording, professional overlays
- 🤖 **Alchemist AI** — Claude chat with live web search for current prices/news, SSE streaming responses
- 📊 **Watchlist** — 15 pairs with simulated live ticks, Frankfurter API for major pairs every 30s
- 📅 **Economic Calendar** — Live events from ForexFactory (proxied), countdown timers, AI analysis on click
- 📓 **Trade Journal** — Full CRUD with PostgreSQL, win rate / net pips stats, AI insights
- ⚙️ **Settings** — Accent color picker, font size, API key, audio volume, notifications, risk defaults

## User preferences

- Gold (XAUUSD) price is $4700+ in 2026 — never use lower training data prices
- AI must use web_search to fetch CURRENT live prices before any analysis
- Cinematic dark gold premium UI throughout
- Logo: `/jj-trades-logo.jpg` used in sidebar, favicon, settings profile

## Gotchas

- API key priority: `ANTHROPIC_API_KEY` env var > Replit `AI_INTEGRATIONS_ANTHROPIC_API_KEY` (both get web_search beta header)
- Never call external APIs directly from frontend (CORS) — always use `/api/proxy/*` backend routes
- Do not run `pnpm dev` at workspace root — use individual package filters
- For local dev: copy `artifacts/ethiostream-pro/.env.example` to root `.env`

## Pointers

- See `artifacts/ethiostream-pro/README.md` for local hosting guide
- See the `pnpm-workspace` skill for workspace structure and TypeScript setup
