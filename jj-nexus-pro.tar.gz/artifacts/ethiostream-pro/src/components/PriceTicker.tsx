import React, { useState, useEffect, useRef } from 'react';
import { FOREX_PAIRS } from '@/lib/mockData';
import { TrendingUp, TrendingDown } from 'lucide-react';

// Initialize momentum for each pair
const initialPairs = FOREX_PAIRS.map(p => ({
  ...p,
  momentum: (Math.random() - 0.5) * 0.005, // Directional drift
}));

export function PriceTicker() {
  const [pairs, setPairs] = useState(initialPairs);

  useEffect(() => {
    const interval = setInterval(() => {
      setPairs(prev => prev.map(p => {
        // Change momentum slightly, occasionally reverse it
        let newMomentum = p.momentum + (Math.random() - 0.5) * 0.001;
        if (Math.random() < 0.05) newMomentum = -newMomentum * 0.5; // 5% chance to reverse

        const fluctuation = newMomentum * p.price + (Math.random() - 0.5) * 0.0005 * p.price;
        const newPrice = Math.max(0, p.price + fluctuation);
        
        // Spread simulation
        const spread = newPrice * (p.price < 10 ? 0.0001 : 0.00005);
        const newBid = newPrice - spread / 2;
        const newAsk = newPrice + spread / 2;

        const newChange = p.change + fluctuation;
        const newChangePercent = (newChange / (p.price - p.change)) * 100;
        
        return {
          ...p,
          price: newPrice,
          bid: newBid,
          ask: newAsk,
          change: newChange,
          changePercent: newChangePercent,
          momentum: newMomentum
        };
      }));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const TickerContent = () => (
    <div className="flex items-center whitespace-nowrap px-4 space-x-8">
      {pairs.map((p, i) => {
        const isPositive = p.change >= 0;
        const decimals = p.price < 10 ? 4 : 2;
        return (
          <div key={i} className="flex items-center space-x-3 text-sm font-mono">
            <span className="font-bold text-[hsl(var(--foreground))]">{p.symbol}</span>
            <span className="text-[hsl(var(--muted-foreground))] flex flex-col items-end text-[10px] leading-tight">
              <span>{p.ask.toFixed(decimals)}</span>
              <span>{p.bid.toFixed(decimals)}</span>
            </span>
            <span className="text-[hsl(var(--muted-foreground))] text-base ml-1">{p.price.toFixed(decimals)}</span>
            <span className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
              {isPositive ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
              {Math.abs(p.changePercent).toFixed(2)}%
            </span>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="flex-1 overflow-hidden flex items-center bg-black/50 border-b border-[hsl(var(--border))] h-12 relative z-10 backdrop-blur-md">
      <div className="flex animate-[marquee_40s_linear_infinite]">
        <TickerContent />
        <TickerContent />
      </div>
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
