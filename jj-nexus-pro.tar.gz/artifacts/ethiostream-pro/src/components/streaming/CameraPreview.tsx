import { useRef, useEffect } from 'react'
import { useCamera } from '../../context/CameraContext'

export default function CameraPreview({ style }: { style?: React.CSSProperties }) {
  const { stream, filters, error } = useCamera()
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream
      videoRef.current.play().catch(() => {})
    }
  }, [stream])

  const filterString = `brightness(${filters.brightness}%) contrast(${filters.contrast}%) saturate(${filters.saturation}%)`
  const transformString = `scale(${filters.zoom}) ${filters.flipped ? 'scaleX(-1)' : ''}`

  if (error) {
    return (
      <div style={{ ...style, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: '#0a0a0a', color: '#D4AF37', flexDirection: 'column', gap: 12, padding: 24 }}>
        <span style={{ fontSize: 40 }}>📷</span>
        <p style={{ textAlign: 'center', fontSize: 14 }}>{error}</p>
        <p style={{ fontSize: 12, color: '#888', textAlign: 'center' }}>
          Go to browser Settings → Privacy → Camera → Allow for this site
        </p>
      </div>
    )
  }

  if (!stream) {
    return (
      <div style={{ ...style, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: '#0a0a0a', color: '#666', flexDirection: 'column', gap: 12 }}>
        <span style={{ fontSize: 40 }}>🎥</span>
        <p style={{ fontSize: 14 }}>No camera active — click Enable Camera</p>
      </div>
    )
  }

  return (
    <video
      ref={videoRef}
      autoPlay
      muted
      playsInline
      style={{
        ...style,
        objectFit: 'cover',
        filter: filterString,
        transform: transformString,
        display: 'block'
      }}
    />
  )
}
