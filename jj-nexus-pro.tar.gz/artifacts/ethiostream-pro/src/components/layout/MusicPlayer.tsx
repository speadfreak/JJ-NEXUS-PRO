import { useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Music2, Play, Pause, SkipBack, SkipForward, Shuffle,
  Repeat, Volume2, VolumeX, X, ChevronUp, Youtube,
  Minimize2, Maximize2
} from 'lucide-react';
import { PLAYLIST, type Track } from '@/data/playlist';

const CATEGORY_COLORS: Record<string, string> = {
  International: 'text-blue-400 bg-blue-400/10',
  Ethiopian: 'text-green-400 bg-green-400/10',
  Ambient: 'text-[var(--gold)] bg-[rgba(212,175,55,0.1)]',
};

function Equalizer({ playing }: { playing: boolean }) {
  return (
    <span className="flex items-end gap-[2px] h-4 shrink-0">
      {[0.6, 1, 0.75, 0.9, 0.5].map((h, i) => (
        <span
          key={i}
          className="w-[3px] rounded-sm bg-[var(--gold)]"
          style={{
            height: playing ? `${h * 14}px` : '3px',
            animation: playing ? `eq-bar 0.55s ease-in-out ${i * 0.08}s infinite alternate` : 'none',
            transition: 'height 0.25s',
          }}
        />
      ))}
    </span>
  );
}

export function MusicPlayer({ collapsed, sidebarWidth }: { collapsed: boolean; sidebarWidth: number }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.3);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [ytKey, setYtKey] = useState(0); // force iframe remount

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const track = PLAYLIST[currentIndex];
  const isAmbient = !track?.youtubeId && !!track?.url;
  const isYouTube = !!track?.youtubeId;

  // load saved state
  useEffect(() => {
    const v = localStorage.getItem('musicVolume');
    if (v) setVolume(Number(v));
    const idx = localStorage.getItem('musicTrackIdx');
    if (idx) {
      const n = Number(idx);
      if (n >= 0 && n < PLAYLIST.length) setCurrentIndex(n);
    }
  }, []);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
    localStorage.setItem('musicVolume', String(volume));
  }, [volume]);

  const switchTrack = useCallback((idx: number, autoplay = true) => {
    // stop current ambient
    if (audioRef.current) { audioRef.current.pause(); audioRef.current.currentTime = 0; }
    setIsPlaying(false);
    setProgress(0);
    setCurrentIndex(idx);
    setYtKey(k => k + 1);
    localStorage.setItem('musicTrackIdx', String(idx));
    const t = PLAYLIST[idx];
    if (autoplay) {
      if (!t?.youtubeId && t?.url) {
        // ambient — play via audio element
        setTimeout(() => {
          if (!audioRef.current) return;
          audioRef.current.src = t.url!;
          audioRef.current.volume = volume;
          audioRef.current.play()
            .then(() => setIsPlaying(true))
            .catch(() => setIsPlaying(false));
        }, 60);
      } else if (t?.youtubeId) {
        // YouTube — iframe with autoplay=1 handles it
        setIsPlaying(true);
      }
    }
  }, [volume]);

  const getNextIdx = useCallback((cur: number) => {
    if (shuffle) {
      let n = cur;
      while (n === cur && PLAYLIST.length > 1) n = Math.floor(Math.random() * PLAYLIST.length);
      return n;
    }
    return (cur + 1) % PLAYLIST.length;
  }, [shuffle]);

  const getPrevIdx = useCallback((cur: number) => {
    if (shuffle) return Math.floor(Math.random() * PLAYLIST.length);
    return (cur - 1 + PLAYLIST.length) % PLAYLIST.length;
  }, [shuffle]);

  const handleTogglePlay = useCallback(() => {
    if (!track) return;
    if (isAmbient) {
      if (!audioRef.current) return;
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    } else if (isYouTube) {
      // Toggle: remount iframe to restart, or just toggle state
      setIsPlaying(p => {
        if (!p) setYtKey(k => k + 1);
        return !p;
      });
    }
  }, [track, isAmbient, isYouTube, isPlaying]);

  const handleNext = useCallback(() => switchTrack(getNextIdx(currentIndex)), [switchTrack, getNextIdx, currentIndex]);
  const handlePrev = useCallback(() => switchTrack(getPrevIdx(currentIndex)), [switchTrack, getPrevIdx, currentIndex]);

  const handleEnded = useCallback(() => {
    if (repeat) { audioRef.current?.play().catch(() => {}); }
    else { handleNext(); }
  }, [repeat, handleNext]);

  const handleTimeUpdate = () => {
    if (!audioRef.current) return;
    setProgress(audioRef.current.currentTime);
    setDuration(audioRef.current.duration || 0);
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const t = Number(e.target.value);
    setProgress(t);
    if (audioRef.current) audioRef.current.currentTime = t;
  };

  const fmt = (s: number) => {
    if (!s || isNaN(s)) return '0:00';
    return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  };

  const categories = ['All', 'International', 'Ethiopian', 'Ambient'] as const;
  const filteredTracks = activeCategory === 'All' ? PLAYLIST : PLAYLIST.filter(t => t.category === activeCategory);

  // ── Floating YouTube iframe player (portal, visible, autoplay) ──
  const ytPlayer = isYouTube && isPlaying && track?.youtubeId
    ? createPortal(
        <div
          className="fixed z-[9990] shadow-2xl border border-[rgba(212,175,55,0.4)] rounded-xl overflow-hidden"
          style={{ bottom: 80, right: 24 }}
        >
          <div className="flex items-center justify-between bg-[#0a0a0a] px-3 py-1.5 border-b border-[rgba(212,175,55,0.15)]">
            <div className="flex items-center gap-2">
              <Youtube className="w-3.5 h-3.5 text-red-500" />
              <span className="text-[11px] font-medium text-white truncate max-w-[180px]">{track.title}</span>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => setIsPlaying(false)} className="p-1 text-gray-500 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <iframe
            key={ytKey}
            src={`https://www.youtube.com/embed/${track.youtubeId}?autoplay=1&rel=0&modestbranding=1&enablejsapi=1`}
            title={track.title}
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
            className="block"
            style={{ width: 320, height: 180, border: 'none' }}
          />
          <div className="bg-[#0a0a0a] px-3 py-1.5 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <button onClick={handlePrev} className="p-1 text-gray-400 hover:text-white"><SkipBack className="w-3.5 h-3.5" /></button>
              <button onClick={handleNext} className="p-1 text-gray-400 hover:text-white"><SkipForward className="w-3.5 h-3.5" /></button>
            </div>
            <span className="text-[9px] text-gray-600">playing in app</span>
          </div>
        </div>,
        document.body
      )
    : null;

  // ── Full playlist panel (portal to escape sidebar stacking ctx) ──
  const playlistPanel = panelOpen
    ? createPortal(
        <div className="fixed inset-0 z-[9980]" style={{ pointerEvents: 'none' }}>
          {/* backdrop */}
          <div
            className="absolute inset-0 bg-black/40"
            style={{ pointerEvents: 'auto' }}
            onClick={() => setPanelOpen(false)}
          />
          <motion.div
            initial={{ x: -340, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -340, opacity: 0 }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            className="absolute top-0 bottom-0 bg-[#0a0a0a] border-r border-[rgba(212,175,55,0.25)] flex flex-col shadow-2xl"
            style={{ left: sidebarWidth, width: 340, pointerEvents: 'auto' }}
            onClick={e => e.stopPropagation()}
          >
            {/* Panel header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-[rgba(212,175,55,0.15)] shrink-0">
              <div className="flex items-center gap-2">
                <Music2 className="w-4 h-4 text-[var(--gold)]" />
                <span className="font-semibold text-sm text-white">JJ PLAYLIST</span>
                <span className="text-[10px] text-gray-500">{PLAYLIST.length} tracks</span>
              </div>
              <button onClick={() => setPanelOpen(false)} className="text-gray-500 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Now playing + controls */}
            {track && (
              <div className="px-4 py-3 bg-[rgba(212,175,55,0.04)] border-b border-[rgba(212,175,55,0.1)] shrink-0">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-lg bg-[rgba(212,175,55,0.15)] flex items-center justify-center shrink-0">
                    {isYouTube ? <Youtube className="w-5 h-5 text-red-500" /> : <Equalizer playing={isPlaying} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-white truncate">{track.title}</p>
                    <p className="text-[11px] text-gray-400 truncate">{track.artist}</p>
                  </div>
                  <span className={`text-[9px] px-2 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[track.category] ?? ''}`}>
                    {track.category}
                  </span>
                </div>

                {/* Progress bar (ambient only) */}
                {isAmbient && duration > 0 && (
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-[9px] text-gray-600 font-mono w-8">{fmt(progress)}</span>
                    <input type="range" min={0} max={duration} step={0.5} value={progress}
                      onChange={handleSeek} className="flex-1 h-1 accent-[var(--gold)] cursor-pointer" />
                    <span className="text-[9px] text-gray-600 font-mono w-8 text-right">{fmt(duration)}</span>
                  </div>
                )}

                {isYouTube && (
                  <p className="text-[9px] text-gray-600 mb-2">
                    {isPlaying ? '▶ Playing in floating player (bottom-right)' : '▷ Click play to open in-app'}
                  </p>
                )}

                {/* Controls */}
                <div className="flex items-center justify-between mb-2">
                  <button onClick={() => setShuffle(v => !v)}
                    className={`flex items-center gap-1 text-[10px] px-2 py-1 rounded ${shuffle ? 'bg-[rgba(212,175,55,0.2)] text-[var(--gold)]' : 'text-gray-600 hover:text-gray-400'}`}>
                    <Shuffle className="w-3 h-3" /> Shuffle
                  </button>
                  <div className="flex items-center gap-2">
                    <button onClick={handlePrev} className="p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-white/5">
                      <SkipBack className="w-4 h-4" />
                    </button>
                    <button onClick={handleTogglePlay}
                      className="w-9 h-9 rounded-full bg-[var(--gold)] flex items-center justify-center text-black hover:bg-yellow-300 shadow-[0_0_12px_rgba(212,175,55,0.5)]">
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                    </button>
                    <button onClick={handleNext} className="p-1.5 text-gray-400 hover:text-white rounded-full hover:bg-white/5">
                      <SkipForward className="w-4 h-4" />
                    </button>
                  </div>
                  <button onClick={() => setRepeat(v => !v)}
                    className={`flex items-center gap-1 text-[10px] px-2 py-1 rounded ${repeat ? 'bg-[rgba(212,175,55,0.2)] text-[var(--gold)]' : 'text-gray-600 hover:text-gray-400'}`}>
                    <Repeat className="w-3 h-3" /> Repeat
                  </button>
                </div>

                {/* Volume */}
                <div className="flex items-center gap-2">
                  <VolumeX className="w-3 h-3 text-gray-600 shrink-0" />
                  <input type="range" min={0} max={1} step={0.05} value={volume}
                    onChange={e => setVolume(Number(e.target.value))}
                    className="flex-1 h-1 accent-[var(--gold)] cursor-pointer" />
                  <Volume2 className="w-3 h-3 text-gray-400 shrink-0" />
                  <span className="text-[9px] font-mono text-gray-500 w-7 text-right">{Math.round(volume * 100)}%</span>
                </div>
              </div>
            )}

            {/* Category tabs */}
            <div className="flex gap-1 px-3 py-2 border-b border-[rgba(212,175,55,0.1)] shrink-0 overflow-x-auto scrollbar-hide">
              {categories.map(cat => (
                <button key={cat} onClick={() => setActiveCategory(cat)}
                  className={`text-[10px] px-3 py-1 rounded-full whitespace-nowrap font-medium transition-colors ${
                    activeCategory === cat ? 'bg-[var(--gold)] text-black' : 'text-gray-500 hover:text-white bg-white/5'
                  }`}>
                  {cat}
                </button>
              ))}
            </div>

            {/* Track list */}
            <div className="flex-1 overflow-y-auto">
              {filteredTracks.map((t: Track) => {
                const idx = PLAYLIST.indexOf(t);
                const isCurrent = idx === currentIndex;
                return (
                  <button key={t.id} onClick={() => { switchTrack(idx); }}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-all group border-l-2 ${
                      isCurrent ? 'bg-[rgba(212,175,55,0.08)] border-[var(--gold)]' : 'border-transparent hover:bg-white/5'
                    }`}>
                    <div className="w-5 shrink-0 flex items-center justify-center">
                      {isCurrent && isPlaying
                        ? <Equalizer playing />
                        : <span className={`text-[10px] font-mono ${isCurrent ? 'text-[var(--gold)]' : 'text-gray-600 group-hover:text-gray-400'}`}>
                            {String(idx + 1).padStart(2, '0')}
                          </span>
                      }
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-medium truncate ${isCurrent ? 'text-[var(--gold)]' : 'text-gray-200'}`}>{t.title}</p>
                      <p className="text-[10px] text-gray-500 truncate">{t.artist}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-medium ${CATEGORY_COLORS[t.category] ?? 'text-gray-500 bg-white/5'}`}>
                        {t.category === 'Ethiopian' ? 'ET' : t.category === 'International' ? 'INT' : 'AMB'}
                      </span>
                      {t.youtubeId && <Youtube className="w-3 h-3 text-red-500/50" />}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="px-4 py-2 border-t border-[rgba(212,175,55,0.08)] shrink-0 text-center">
              <p className="text-[9px] text-gray-700">YouTube: plays in floating window • Ambient: plays inline</p>
            </div>
          </motion.div>
        </div>,
        document.body
      )
    : null;

  return (
    <>
      <style>{`
        @keyframes eq-bar { from { transform: scaleY(0.25); } to { transform: scaleY(1); } }
        .scrollbar-hide::-webkit-scrollbar { display: none; }
      `}</style>

      {/* Hidden audio element for ambient tracks */}
      <audio
        ref={audioRef}
        preload="none"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
        onEnded={handleEnded}
        onError={() => setIsPlaying(false)}
      />

      {/* ── Mini player in sidebar ── */}
      <div className="border-t border-[rgba(212,175,55,0.1)] px-2 py-2 shrink-0">
        {collapsed ? (
          <button onClick={() => setPanelOpen(v => !v)}
            className={`w-full flex justify-center items-center py-1.5 rounded transition-colors ${isPlaying ? 'text-[var(--gold)]' : 'text-gray-500 hover:text-[var(--gold)]'}`}
            title="Music Player">
            {isPlaying ? <Equalizer playing /> : <Music2 className="w-5 h-5" />}
          </button>
        ) : (
          <div className="flex flex-col gap-1.5">
            {/* Track name row */}
            <button onClick={() => setPanelOpen(v => !v)}
              className="flex items-center gap-2 w-full text-left group min-w-0">
              <div className={`shrink-0 ${isPlaying ? 'text-[var(--gold)]' : 'text-gray-500'}`}>
                {isPlaying ? <Equalizer playing /> : <Music2 className="w-4 h-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-medium text-white truncate leading-tight">{track?.title ?? 'No track'}</p>
                <p className="text-[9px] text-gray-500 truncate leading-tight">{track?.artist ?? ''}</p>
              </div>
              <ChevronUp className={`w-3 h-3 text-gray-500 shrink-0 transition-transform duration-200 ${panelOpen ? 'rotate-180' : 'rotate-0'}`} />
            </button>

            {/* Ambient progress bar */}
            {isAmbient && duration > 0 && (
              <input type="range" min={0} max={duration} step={0.5} value={progress}
                onChange={handleSeek}
                className="w-full h-0.5 accent-[var(--gold)] cursor-pointer rounded-full" />
            )}

            {/* Playback controls */}
            <div className="flex items-center justify-between">
              <button onClick={() => setShuffle(v => !v)}
                className={`p-1 rounded ${shuffle ? 'text-[var(--gold)]' : 'text-gray-600 hover:text-gray-400'}`}>
                <Shuffle className="w-3 h-3" />
              </button>
              <button onClick={handlePrev} className="p-1 text-gray-400 hover:text-white">
                <SkipBack className="w-3.5 h-3.5" />
              </button>
              <button onClick={handleTogglePlay}
                className="w-7 h-7 rounded-full bg-[var(--gold)] flex items-center justify-center text-black hover:bg-yellow-300 shadow-[0_0_8px_rgba(212,175,55,0.4)]">
                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 ml-0.5" />}
              </button>
              <button onClick={handleNext} className="p-1 text-gray-400 hover:text-white">
                <SkipForward className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => setRepeat(v => !v)}
                className={`p-1 rounded ${repeat ? 'text-[var(--gold)]' : 'text-gray-600 hover:text-gray-400'}`}>
                <Repeat className="w-3 h-3" />
              </button>
            </div>

            {/* Volume row */}
            <div className="flex items-center gap-1.5">
              <VolumeX className="w-3 h-3 text-gray-600 shrink-0" />
              <input type="range" min={0} max={1} step={0.05} value={volume}
                onChange={e => setVolume(Number(e.target.value))}
                className="flex-1 h-0.5 accent-[var(--gold)] cursor-pointer" />
              <span className="text-[9px] font-mono text-gray-600 w-6 text-right">{Math.round(volume * 100)}</span>
            </div>
          </div>
        )}
      </div>

      {/* Portals */}
      <AnimatePresence>{playlistPanel}</AnimatePresence>
      {ytPlayer}
    </>
  );
}
