import { useState, useRef, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { ParticleCanvas } from './ParticleCanvas';
import { PriceTicker } from './PriceTicker';
import { LayoutDashboard, Radio, Brain, ListOrdered, BookOpen, Settings, Menu, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';
import NotificationCenter, { NotificationToasts } from './notifications/NotificationCenter';
import { AlertService } from '@/services/AlertService';
import { MusicPlayer } from './layout/MusicPlayer';

const NAV_ITEMS = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/streaming', label: 'Studio', icon: Radio },
  { path: '/alchemist', label: 'Alchemist AI', icon: Brain },
  { path: '/watchlist', label: 'Watchlist', icon: ListOrdered },
  { path: '/journal', label: 'Journal', icon: BookOpen },
  { path: '/calendar', label: 'Calendar', icon: Calendar },
  { path: '/settings', label: 'Settings', icon: Settings },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [location] = useLocation();
  const welcomeFired = useRef(false);

  useEffect(() => {
    if (welcomeFired.current) return;
    welcomeFired.current = true;
    const t = setTimeout(() => {
      AlertService.notify('🚀 JJ Nexus Pro Online', 'Markets are live. Alchemist AI is ready. Good trading!');
    }, 2000);
    const t2 = setTimeout(() => {
      const utcH = new Date().getUTCHours();
      const londonActive = utcH >= 8 && utcH < 17;
      const nyActive = utcH >= 13 && utcH < 22;
      if (londonActive && nyActive) {
        AlertService.notify('⚡ London & New York Overlap', 'Highest liquidity window is open — prime time for SMC setups.');
      } else if (londonActive) {
        AlertService.notify('🇬🇧 London Session Active', 'London is open. Watch GBPUSD, EURUSD, XAUUSD for breakouts.');
      } else if (nyActive) {
        AlertService.notify('🇺🇸 New York Session Active', 'NY is open. DXY correlation in play — watch XAUUSD reaction.');
      }
    }, 5000);
    return () => { clearTimeout(t); clearTimeout(t2); };
  }, []);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#050505] text-[hsl(var(--foreground))]">
      <ParticleCanvas />

      {/* Sidebar */}
      <motion.div
        animate={{ width: collapsed ? 64 : 220 }}
        className="flex flex-col h-full bg-black/40 backdrop-blur-xl border-r border-[rgba(212,175,55,0.2)] z-20 shrink-0 overflow-hidden"
      >
        {/* Logo */}
        <div className="h-16 flex items-center justify-center border-b border-[rgba(212,175,55,0.1)] px-2 shrink-0">
          <div className="relative group cursor-pointer overflow-hidden rounded-full shrink-0">
            <img src="/jj-trades-logo.jpg" alt="Logo" className="w-8 h-8 rounded-full border border-[var(--gold)]" />
            <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover:animate-[shimmer_1.5s_infinite] skew-x-12" />
          </div>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="ml-3 font-serif font-bold text-[var(--gold)] tracking-wider whitespace-nowrap"
            >
              JJ NEXUS PRO
            </motion.span>
          )}
        </div>

        {/* Nav items */}
        <div className="flex-1 py-4 flex flex-col gap-1 px-2 overflow-y-auto overflow-x-hidden">
          {NAV_ITEMS.map((item) => {
            const isActive = location === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                href={item.path}
                className={`flex items-center px-3 py-2.5 rounded-md transition-all duration-300 relative group overflow-hidden ${isActive ? 'bg-[var(--gold)] text-black' : 'hover:bg-white/5 text-[hsl(var(--muted-foreground))]'}`}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-black' : 'group-hover:text-[var(--gold)] transition-colors'}`} />
                {!collapsed && (
                  <span className={`ml-3 font-medium whitespace-nowrap text-sm ${isActive ? 'text-black' : 'group-hover:text-white transition-colors'}`}>
                    {item.label}
                  </span>
                )}
                {isActive && !collapsed && (
                  <motion.div layoutId="sidebar-active" className="absolute inset-0 rounded-md border border-[var(--gold)] shadow-[0_0_10px_rgba(212,175,55,0.5)] pointer-events-none" />
                )}
              </Link>
            );
          })}
        </div>

        {/* Music Player (integrated into sidebar) */}
        <MusicPlayer collapsed={collapsed} sidebarWidth={collapsed ? 64 : 220} />

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="h-10 flex items-center justify-center border-t border-[rgba(212,175,55,0.1)] hover:bg-white/5 transition-colors text-[hsl(var(--muted-foreground))] shrink-0"
        >
          <Menu className="w-5 h-5" />
        </button>
      </motion.div>

      {/* Main Area */}
      <div className="flex flex-col flex-1 min-w-0 z-10">
        <header className="h-12 flex shrink-0 border-b border-[rgba(212,175,55,0.2)] bg-black/40 backdrop-blur-xl">
          <PriceTicker />
          <div className="flex items-center px-4 gap-3 bg-[#050505] shrink-0">
            <NotificationCenter />
            <div className="w-8 h-8 rounded-full bg-[var(--gold)] flex items-center justify-center text-black font-bold text-xs">
              JJ
            </div>
          </div>
        </header>

        <NotificationToasts />
        <main className="flex-1 overflow-y-auto p-4 md:p-6 relative pb-10">
          {children}
        </main>
        <footer className="h-8 shrink-0 flex items-center justify-center border-t border-[rgba(212,175,55,0.08)] bg-black/60 backdrop-blur-sm text-[10px] text-gray-600 tracking-widest uppercase select-none">
          JJ NEXUS PRO &nbsp;•&nbsp; 2026 &nbsp;•&nbsp; Elite Forex Command Center
        </footer>
      </div>

      <style>{`
        @keyframes shimmer { 100% { transform: translateX(100%); } }
      `}</style>
    </div>
  );
}
