import { useState, useEffect, useCallback, useRef } from 'react'
import { createPortal } from 'react-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Bell, X, Volume2 } from 'lucide-react'
import { AlertService, JJNotification } from '@/services/AlertService'

interface ToastItem extends JJNotification {
  dying?: boolean
}

export function NotificationToasts() {
  const [toasts, setToasts] = useState<ToastItem[]>([])

  useEffect(() => {
    const unsub = AlertService.onNotification((n) => {
      setToasts(prev => [...prev.slice(-4), { ...n }])
      setTimeout(() => {
        setToasts(prev => prev.map(t => t.id === n.id ? { ...t, dying: true } : t))
        setTimeout(() => setToasts(prev => prev.filter(t => t.id !== n.id)), 400)
      }, 5000)
    })
    return unsub
  }, [])

  return createPortal(
    <div className="fixed bottom-6 right-6 z-[9999] flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        {toasts.map(toast => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, x: 60, scale: 0.9 }}
            animate={{ opacity: toast.dying ? 0 : 1, x: toast.dying ? 60 : 0, scale: 1 }}
            exit={{ opacity: 0, x: 60 }}
            className="pointer-events-auto bg-[#0d0d0d] border border-[rgba(212,175,55,0.4)] rounded-lg p-4 shadow-2xl max-w-xs"
          >
            <div className="flex items-start gap-3">
              <Bell className="w-4 h-4 text-[var(--gold)] mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white">{toast.title}</p>
                <p className="text-xs text-gray-400 mt-0.5">{toast.body}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>,
    document.body
  )
}

export default function NotificationCenter() {
  const [open, setOpen] = useState(false)
  const [notifications, setNotifications] = useState<JJNotification[]>([])
  const [unread, setUnread] = useState(0)
  const btnRef = useRef<HTMLButtonElement>(null)
  const [dropPos, setDropPos] = useState({ top: 0, right: 0 })

  const addNotification = useCallback((n: JJNotification) => {
    setNotifications(prev => [n, ...prev].slice(0, 50))
    setUnread(u => u + 1)
  }, [])

  useEffect(() => {
    const unsub = AlertService.onNotification(addNotification)
    return unsub
  }, [addNotification])

  const handleOpen = () => {
    if (btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect()
      setDropPos({ top: rect.bottom + 8, right: window.innerWidth - rect.right })
    }
    setOpen(o => {
      if (!o) setUnread(0)
      return !o
    })
  }

  const clearAll = () => { setNotifications([]); setUnread(0) }

  const formatTime = (ts: number) => {
    const diff = Date.now() - ts
    if (diff < 60000) return 'Just now'
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`
    return new Date(ts).toLocaleDateString()
  }

  const dropdown = open
    ? createPortal(
        <>
          <div className="fixed inset-0 z-[9995]" onClick={() => setOpen(false)} />
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className="fixed z-[9996] w-80 bg-[#0a0a0a] border border-[rgba(212,175,55,0.3)] rounded-xl shadow-2xl overflow-hidden"
            style={{ top: dropPos.top, right: dropPos.right }}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-[rgba(212,175,55,0.1)]">
              <span className="text-sm font-bold text-white">Notifications</span>
              <div className="flex gap-2 items-center">
                {notifications.length > 0 && (
                  <button onClick={clearAll} className="text-xs text-gray-500 hover:text-red-400 transition-colors">Clear all</button>
                )}
                <button onClick={() => setOpen(false)} className="text-gray-500 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="max-h-80 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-gray-600">
                  <Bell className="w-8 h-8 mb-2 opacity-30" />
                  <p className="text-sm">No notifications yet</p>
                </div>
              ) : (
                notifications.map(n => (
                  <div key={n.id} className="flex gap-3 px-4 py-3 border-b border-[rgba(255,255,255,0.03)] hover:bg-white/5 transition-colors">
                    <div className="w-2 h-2 rounded-full bg-[var(--gold)] mt-1.5 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-white">{n.title}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{n.body}</p>
                      <p className="text-[10px] text-gray-600 mt-1">{formatTime(n.timestamp)}</p>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="px-4 py-2 border-t border-[rgba(212,175,55,0.1)]">
              <button
                onClick={() => AlertService.requestPermission()}
                className="text-xs text-gray-500 hover:text-[var(--gold)] transition-colors flex items-center gap-1"
              >
                <Volume2 className="w-3 h-3" /> Enable browser alerts
              </button>
            </div>
          </motion.div>
        </>,
        document.body
      )
    : null

  return (
    <div className="relative">
      <button
        ref={btnRef}
        onClick={handleOpen}
        className="relative p-2 rounded-lg hover:bg-white/5 transition-colors text-gray-400 hover:text-[var(--gold)]"
        title="Notifications"
      >
        <Bell className="w-5 h-5" />
        {unread > 0 && (
          <span className="absolute top-0.5 right-0.5 w-4 h-4 bg-red-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>
      <AnimatePresence>{dropdown}</AnimatePresence>
    </div>
  )
}
