import { useRef, useEffect } from 'react'

interface Props {
  symbol?: string
  style?: React.CSSProperties
  className?: string
}

export default function TradingViewWidget({ symbol = 'XAUUSD', style, className }: Props) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current) return
    containerRef.current.innerHTML = ''

    const tvSymbol = symbol === 'XAUUSD' ? 'OANDA:XAUUSD'
      : symbol === 'XAGUSD' ? 'OANDA:XAGUSD'
      : symbol === 'BTCUSD' ? 'BITSTAMP:BTCUSD'
      : symbol === 'ETHUSD' ? 'BITSTAMP:ETHUSD'
      : symbol === 'US30' ? 'DJ:DJI'
      : symbol === 'NAS100' ? 'NASDAQ:NDX'
      : symbol === 'SPX500' ? 'SP:SPX'
      : symbol === 'USOIL' ? 'TVC:USOIL'
      : symbol === 'UKOIL' ? 'TVC:UKOIL'
      : `FX:${symbol}`

    const script = document.createElement('script')
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js'
    script.type = 'text/javascript'
    script.async = true
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: tvSymbol,
      interval: 'H1',
      timezone: 'Etc/UTC',
      theme: 'dark',
      style: '1',
      locale: 'en',
      backgroundColor: '#050505',
      gridColor: 'rgba(212,175,55,0.05)',
      allow_symbol_change: true,
      calendar: false,
      studies: ['RSI@tv-basicstudies', 'MACD@tv-basicstudies'],
      support_host: 'https://www.tradingview.com',
    })
    containerRef.current.appendChild(script)
  }, [symbol])

  return (
    <div
      ref={containerRef}
      className={`tradingview-widget-container ${className ?? ''}`}
      style={{ width: '100%', height: '100%', background: '#050505', ...style }}
    />
  )
}
