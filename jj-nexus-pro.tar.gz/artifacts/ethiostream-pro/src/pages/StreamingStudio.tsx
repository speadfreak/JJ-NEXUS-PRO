import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Camera, CircleDot, Activity, MessageSquare, MonitorPlay } from 'lucide-react';
import { CHAT_MESSAGES } from '@/lib/mockData';
import { SiTiktok, SiYoutube, SiInstagram } from 'react-icons/si';
import QRCode from 'qrcode';
import { useCamera } from '@/context/CameraContext';
import CameraPreview from '@/components/streaming/CameraPreview';
import PiPCameraWindow from '@/components/streaming/PiPCameraWindow';
import TradingViewWidget from '@/components/common/TradingViewWidget';
import ChartSymbolSwitcher from '@/components/common/ChartSymbolSwitcher';

type SceneKey = 'pip' | 'face-chart' | 'full-chart' | 'full-camera' | 'vertical' | 'side-by-side';

const SCENES: { key: SceneKey; label: string }[] = [
  { key: 'pip', label: 'PiP Mode' },
  { key: 'face-chart', label: 'Face + Chart' },
  { key: 'full-chart', label: 'Full Chart' },
  { key: 'full-camera', label: 'Full Camera' },
  { key: 'vertical', label: 'Vertical 9:16' },
  { key: 'side-by-side', label: 'Side by Side' },
];


function RtmpModal({ platform, onClose }: { platform: string; onClose: () => void }) {
  const [rtmpUrl, setRtmpUrl] = useState('');
  const [streamKey, setStreamKey] = useState('');
  const [showKey, setShowKey] = useState(false);

  const rtmpUrls: Record<string, string> = {
    youtube: 'rtmp://a.rtmp.youtube.com/live2',
    tiktok: 'rtmp://push.tiktok.com/live/',
    instagram: 'rtmp://live-api-s.facebook.com:80/rtmp/',
  };

  const defaultUrl = rtmpUrls[platform.toLowerCase()] || '';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-[#0a0a0a] border border-[rgba(212,175,55,0.4)] rounded-xl p-6 w-full max-w-md shadow-[0_0_40px_rgba(212,175,55,0.15)]"
        onClick={e => e.stopPropagation()}
      >
        <h3 className="text-[var(--gold)] font-bold text-lg mb-4 flex items-center gap-2">
          📡 Stream to {platform}
        </h3>
        <div className="space-y-4">
          <div>
            <label className="text-xs text-gray-400 mb-1 block">RTMP URL</label>
            <input
              type="text"
              value={rtmpUrl || defaultUrl}
              onChange={e => setRtmpUrl(e.target.value)}
              placeholder={defaultUrl}
              className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-[var(--gold)]"
            />
          </div>
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Stream Key</label>
            <div className="flex gap-2">
              <input
                type={showKey ? 'text' : 'password'}
                value={streamKey}
                onChange={e => setStreamKey(e.target.value)}
                placeholder="Paste your stream key here"
                className="flex-1 bg-black border border-gray-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-[var(--gold)]"
              />
              <button onClick={() => setShowKey(!showKey)} className="px-3 text-gray-400 hover:text-white border border-gray-700 rounded">
                {showKey ? '🙈' : '👁'}
              </button>
            </div>
          </div>
          <div className="bg-black/60 rounded-lg p-4 text-xs text-gray-400 space-y-1 border border-[rgba(212,175,55,0.1)]">
            <p className="text-[var(--gold)] font-semibold mb-2">How to go live with OBS:</p>
            <p>1. Copy your stream key from {platform}</p>
            <p>2. Open OBS Studio</p>
            <p>3. Settings → Stream → Custom</p>
            <p>4. Paste the RTMP URL and Stream Key</p>
            <p>5. Click "Start Streaming" in OBS</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => navigator.clipboard.writeText(rtmpUrl || defaultUrl)}
              className="flex-1 py-2 bg-[rgba(212,175,55,0.15)] border border-[var(--gold)] text-[var(--gold)] rounded text-sm font-medium hover:bg-[rgba(212,175,55,0.25)]"
            >
              Copy RTMP URL
            </button>
            <a
              href="https://obsproject.com/download"
              target="_blank"
              rel="noreferrer"
              className="flex-1 py-2 bg-black border border-gray-600 text-white rounded text-sm font-medium text-center hover:border-gray-400"
            >
              Get OBS
            </a>
          </div>
        </div>
        <button onClick={onClose} className="mt-4 w-full py-2 text-gray-500 text-sm hover:text-white">Close</button>
      </div>
    </div>
  );
}

export default function StreamingStudio() {
  const { stream, screenStream, isActive, startCamera, stopCamera, startScreenShare, stopScreenShare, filters, setFilters } = useCamera();

  const [activeScene, setActiveScene] = useState<SceneKey>('pip');
  const [chartSymbol, setChartSymbol] = useState('XAUUSD');
  const [chat, setChat] = useState(CHAT_MESSAGES);
  const [chatInput, setChatInput] = useState('');
  const [activeTab, setActiveTab] = useState('Camera');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [overlays, setOverlays] = useState({
    lowerThird: true,
    logo: true,
    ticker: true,
    watermark: false,
  });
  const [lowerThirdText, setLowerThirdText] = useState('JJ TRADES • LIVE ANALYSIS');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState('00:00');
  const recordingTimerRef = useRef<number | null>(null);

  const [fps, setFps] = useState(0);
  const [rtmpModal, setRtmpModal] = useState<string | null>(null);

  useEffect(() => {
    let frameCount = 0;
    let lastTime = performance.now();
    let rafId: number;
    const measure = () => {
      frameCount++;
      const now = performance.now();
      if (now - lastTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastTime = now;
      }
      rafId = requestAnimationFrame(measure);
    };
    rafId = requestAnimationFrame(measure);
    return () => cancelAnimationFrame(rafId);
  }, []);

  useEffect(() => {
    if (canvasRef.current && activeTab === 'Camera') {
      QRCode.toCanvas(canvasRef.current, window.location.origin + '/mobile-cam', {
        width: 150,
        color: { dark: '#D4AF37', light: '#050505' },
        margin: 2,
      }).catch(() => {});
    }
  }, [activeTab]);

  useEffect(() => {
    const chatInterval = setInterval(() => {
      const msgs = ['Is it too late to buy?', 'Nice entry bro', 'JJ the goat!', 'What\'s DXY doing?'];
      const names = ['TradeK', 'SMC_Sniper', 'AlphaFX', 'PipCatcher'];
      setChat(prev => [...prev, {
        id: Date.now(),
        user: names[Math.floor(Math.random() * names.length)],
        text: msgs[Math.floor(Math.random() * msgs.length)]
      }]);
    }, 10000);
    return () => clearInterval(chatInterval);
  }, []);

  const toggleRecording = () => {
    if (isRecording) {
      mediaRecorderRef.current?.stop();
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
      setIsRecording(false);
    } else {
      const s = stream || screenStream;
      if (!s) { alert('Please enable camera or screen share first.'); return; }

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm';
      const recorder = new MediaRecorder(s, { mimeType });
      const chunks: Blob[] = [];

      recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `jjnexus-pro-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.webm`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      };

      recorder.start(1000);
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      setRecordingTime('00:00');

      let secs = 0;
      recordingTimerRef.current = window.setInterval(() => {
        secs++;
        const m = String(Math.floor(secs / 60)).padStart(2, '0');
        const s2 = String(secs % 60).padStart(2, '0');
        setRecordingTime(`${m}:${s2}`);
      }, 1000);
    }
  };

  const getResolution = () => {
    if (!stream) return 'No signal';
    const track = stream.getVideoTracks()[0];
    if (!track) return 'No video';
    const { width, height } = track.getSettings();
    return `${width ?? '?'}×${height ?? '?'}`;
  };

  const renderScene = () => {
    switch (activeScene) {
      case 'pip':
        return (
          <div style={{ position: 'relative', width: '100%', height: '100%' }}>
            <TradingViewWidget symbol={chartSymbol} style={{ width: '100%', height: '100%' }} />
            <PiPCameraWindow />
          </div>
        );
      case 'face-chart':
        return (
          <div style={{ display: 'flex', width: '100%', height: '100%' }}>
            <CameraPreview style={{ width: '40%', height: '100%' }} />
            <TradingViewWidget symbol={chartSymbol} style={{ width: '60%', height: '100%' }} />
          </div>
        );
      case 'full-chart':
        return <TradingViewWidget symbol={chartSymbol} style={{ width: '100%', height: '100%' }} />;
      case 'full-camera':
        return <CameraPreview style={{ width: '100%', height: '100%' }} />;
      case 'vertical':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', width: '100%', height: '100%' }}>
            <TradingViewWidget symbol={chartSymbol} style={{ width: '100%', height: '60%' }} />
            <CameraPreview style={{ width: '100%', height: '40%' }} />
          </div>
        );
      case 'side-by-side':
        return (
          <div style={{ display: 'flex', width: '100%', height: '100%' }}>
            <TradingViewWidget symbol={chartSymbol} style={{ width: '50%', height: '100%' }} />
            <CameraPreview style={{ width: '50%', height: '100%' }} />
          </div>
        );
      default:
        return <TradingViewWidget symbol={chartSymbol} style={{ width: '100%', height: '100%' }} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex flex-col h-full gap-4 max-w-[1600px] mx-auto w-full"
    >
      {rtmpModal && <RtmpModal platform={rtmpModal} onClose={() => setRtmpModal(null)} />}

      {/* Scene Presets */}
      <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar shrink-0">
        {SCENES.map(s => (
          <button
            key={s.key}
            onClick={() => setActiveScene(s.key)}
            className={`px-4 py-2 rounded-md font-medium text-sm transition-all whitespace-nowrap ${
              activeScene === s.key
                ? 'bg-[rgba(212,175,55,0.2)] text-[var(--gold)] border border-[var(--gold)] shadow-[0_0_10px_rgba(212,175,55,0.3)]'
                : 'bg-[hsl(var(--card))] text-[hsl(var(--muted-foreground))] border border-[rgba(212,175,55,0.1)] hover:border-[rgba(212,175,55,0.3)]'
            }`}
          >
            {s.label}
          </button>
        ))}
        <ChartSymbolSwitcher currentSymbol={chartSymbol} onSymbolChange={setChartSymbol} className="shrink-0" />
        <div className="ml-auto flex items-center gap-2 shrink-0">
          {!isActive ? (
            <button
              onClick={() => startCamera()}
              className="px-4 py-2 bg-[var(--gold)] text-black text-sm font-bold rounded hover:bg-yellow-500 transition-colors flex items-center gap-2"
            >
              <Camera className="w-4 h-4" /> Enable Camera
            </button>
          ) : (
            <button
              onClick={stopCamera}
              className="px-4 py-2 bg-red-500/20 text-red-400 border border-red-500/40 text-sm font-bold rounded hover:bg-red-500/30 transition-colors flex items-center gap-2"
            >
              <Camera className="w-4 h-4" /> Stop Camera
            </button>
          )}
          {!screenStream ? (
            <button onClick={startScreenShare} className="px-4 py-2 bg-black border border-gray-600 text-white text-sm font-bold rounded hover:border-[var(--gold)] transition-colors flex items-center gap-2">
              <MonitorPlay className="w-4 h-4" /> Share Screen
            </button>
          ) : (
            <button onClick={stopScreenShare} className="px-4 py-2 bg-red-500 text-white text-sm font-bold rounded hover:bg-red-600 flex items-center gap-2">
              <MonitorPlay className="w-4 h-4" /> Stop Share
            </button>
          )}
        </div>
      </div>

      {/* Main Preview */}
      <div className={`w-full bg-black border border-[rgba(212,175,55,0.2)] rounded-lg relative overflow-hidden shrink-0 shadow-lg ${activeScene === 'vertical' ? 'aspect-[9/16] max-w-[360px] mx-auto' : 'aspect-video'}`}>
        {renderScene()}

        {/* Overlays */}
        {overlays.ticker && (
          <div className="absolute top-0 left-0 w-full h-8 bg-black/80 backdrop-blur border-b border-[var(--gold)]/30 z-20 flex items-center overflow-hidden pointer-events-none">
            <div className="flex whitespace-nowrap animate-[marquee_20s_linear_infinite] text-[var(--gold)] font-mono text-xs">
              <span className="mx-4">XAUUSD 3,340.00 (+0.82%)</span>
              <span className="mx-4">EURUSD 1.1280 (+0.14%)</span>
              <span className="mx-4">GBPUSD 1.3410 (+0.22%)</span>
              <span className="mx-4">USDJPY 145.30 (-0.18%)</span>
              <span className="mx-4">BTCUSD 104,200 (+1.50%)</span>
            </div>
          </div>
        )}

        {isRecording && (
          <div className="absolute top-10 left-4 flex items-center gap-2 bg-black/70 px-3 py-1.5 rounded border border-red-500/50 z-20 pointer-events-none">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-red-400 font-bold tracking-widest text-xs">REC</span>
            <span className="text-white font-mono text-xs ml-1">{recordingTime}</span>
          </div>
        )}

        {overlays.watermark && (
          <div className="absolute top-10 right-4 z-20 opacity-30 pointer-events-none">
            <h1 className="font-serif text-3xl font-bold tracking-widest text-white drop-shadow-md">JJ NEXUS PRO</h1>
          </div>
        )}

        {overlays.logo && (
          <div className="absolute top-4 right-4 z-20 w-14 h-14 rounded-full overflow-hidden border-2 border-[var(--gold)] shadow-[0_0_15px_rgba(212,175,55,0.5)] pointer-events-none">
            <img src="/jj-trades-logo.jpg" alt="Logo" className="w-full h-full object-cover" />
          </div>
        )}

        {overlays.lowerThird && (
          <div className="absolute bottom-10 left-10 z-20">
            <div className="bg-gradient-to-r from-black/90 to-transparent pr-20 py-3 pl-4 border-l-4 border-[var(--gold)] backdrop-blur-md shadow-2xl">
              <input
                type="text"
                value={lowerThirdText}
                onChange={e => setLowerThirdText(e.target.value)}
                className="bg-transparent text-[var(--gold)] font-serif font-bold text-xl tracking-widest uppercase outline-none w-full min-w-[280px]"
              />
              <p className="text-white text-xs font-mono mt-1 tracking-wider uppercase">JJ NEXUS PRO BROADCAST</p>
            </div>
          </div>
        )}
      </div>

      {/* Stream Health Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg shrink-0 overflow-x-auto custom-scrollbar text-sm">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <Activity className={`w-4 h-4 ${isActive ? 'text-[var(--gold)] animate-pulse' : 'text-gray-600'}`} />
            <span className="text-gray-400">FPS:</span>
            <span className="font-mono text-white">{isActive ? fps : 0}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">Resolution:</span>
            <span className="font-mono text-white">{getResolution()}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">Camera:</span>
            <span className={`font-mono ${isActive ? 'text-green-400' : 'text-gray-500'}`}>{isActive ? 'LIVE' : 'OFF'}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">Screen:</span>
            <span className={`font-mono ${screenStream ? 'text-green-400' : 'text-gray-500'}`}>{screenStream ? 'SHARING' : 'OFF'}</span>
          </div>
        </div>
      </div>

      {/* Bottom Columns */}
      <div className="flex-1 flex flex-col md:flex-row gap-4 min-h-[400px]">
        {/* Controls */}
        <div className="flex-[2] border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] flex flex-col overflow-hidden group hover:border-[var(--gold)] transition-colors">
          <div className="flex border-b border-[rgba(212,175,55,0.1)] shrink-0">
            {['Camera', 'Overlays', 'Stream'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${
                  activeTab === tab ? 'text-[var(--gold)] border-b-2 border-[var(--gold)] bg-white/5' : 'text-[hsl(var(--muted-foreground))] hover:text-white hover:bg-white/5'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="p-6 flex-1 overflow-y-auto custom-scrollbar">
            {activeTab === 'Camera' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-5">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-white">Mirror Camera</span>
                    <button
                      onClick={() => setFilters({ flipped: !filters.flipped })}
                      className={`w-12 h-6 rounded-full p-1 transition-colors ${filters.flipped ? 'bg-[var(--gold)]' : 'bg-gray-700'}`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full transition-transform ${filters.flipped ? 'translate-x-6' : ''}`} />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-gray-400">
                      <span>Zoom</span>
                      <span className="text-[var(--gold)] font-mono">{filters.zoom.toFixed(1)}x</span>
                    </div>
                    <input type="range" min="1" max="3" step="0.1" value={filters.zoom} onChange={e => setFilters({ zoom: Number(e.target.value) })} className="w-full accent-[var(--gold)]" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-gray-400">
                      <span>Brightness</span>
                      <span className="text-[var(--gold)] font-mono">{filters.brightness}%</span>
                    </div>
                    <input type="range" min="50" max="150" value={filters.brightness} onChange={e => setFilters({ brightness: Number(e.target.value) })} className="w-full accent-[var(--gold)]" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-gray-400">
                      <span>Contrast</span>
                      <span className="text-[var(--gold)] font-mono">{filters.contrast}%</span>
                    </div>
                    <input type="range" min="50" max="150" value={filters.contrast} onChange={e => setFilters({ contrast: Number(e.target.value) })} className="w-full accent-[var(--gold)]" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-gray-400">
                      <span>Saturation</span>
                      <span className="text-[var(--gold)] font-mono">{filters.saturation}%</span>
                    </div>
                    <input type="range" min="0" max="200" value={filters.saturation} onChange={e => setFilters({ saturation: Number(e.target.value) })} className="w-full accent-[var(--gold)]" />
                  </div>
                </div>

                <div className="p-4 border border-[rgba(212,175,55,0.2)] rounded-lg bg-black/40 flex flex-col items-center justify-center text-center">
                  <h4 className="text-sm font-bold text-[var(--gold)] mb-2">Phone Camera Source</h4>
                  <p className="text-xs text-[hsl(var(--muted-foreground))] mb-4">Scan to stream from your mobile via WebRTC</p>
                  <div className="bg-white p-2 rounded-lg">
                    <canvas ref={canvasRef} className="w-32 h-32" />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'Overlays' && (
              <div className="space-y-4">
                {Object.entries(overlays).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between p-4 rounded-lg bg-black/40 border border-[rgba(212,175,55,0.1)]">
                    <span className="text-sm font-medium capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <button
                      onClick={() => setOverlays(prev => ({ ...prev, [key]: !value }))}
                      className={`w-10 h-5 rounded-full p-1 transition-colors ${value ? 'bg-[var(--gold)]' : 'bg-gray-700'}`}
                    >
                      <div className={`w-3 h-3 bg-white rounded-full transition-transform ${value ? 'translate-x-5' : ''}`} />
                    </button>
                  </div>
                ))}
                {overlays.lowerThird && (
                  <div className="p-4 rounded-lg bg-black/40 border border-[rgba(212,175,55,0.1)]">
                    <label className="text-xs text-gray-400 mb-2 block">Lower Third Text</label>
                    <input
                      type="text"
                      value={lowerThirdText}
                      onChange={e => setLowerThirdText(e.target.value)}
                      className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm text-[var(--gold)] focus:outline-none focus:border-[var(--gold)]"
                    />
                  </div>
                )}
              </div>
            )}

            {activeTab === 'Stream' && (
              <div className="space-y-4">
                {[
                  { id: 'YouTube', icon: SiYoutube, color: 'text-red-500' },
                  { id: 'TikTok', icon: SiTiktok, color: 'text-white' },
                  { id: 'Instagram', icon: SiInstagram, color: 'text-pink-500' },
                ].map(platform => {
                  const Icon = platform.icon;
                  return (
                    <div key={platform.id} className="flex items-center justify-between p-4 rounded-lg bg-black/40 border border-[rgba(212,175,55,0.1)]">
                      <div className="flex items-center gap-3">
                        <Icon className={`w-6 h-6 ${platform.color}`} />
                        <span className="font-medium text-white">{platform.id} Live</span>
                      </div>
                      <button
                        onClick={() => setRtmpModal(platform.id)}
                        className="px-4 py-1.5 bg-[var(--gold)] text-black text-xs font-bold rounded hover:bg-yellow-500 transition-colors"
                      >
                        SETUP STREAM
                      </button>
                    </div>
                  );
                })}

                <div className="mt-6 pt-6 border-t border-[rgba(212,175,55,0.1)]">
                  <button
                    onClick={toggleRecording}
                    className={`w-full py-4 rounded-lg font-bold flex items-center justify-center gap-2 transition-all ${
                      isRecording
                        ? 'bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)]'
                        : 'bg-black border border-gray-600 text-white hover:border-[var(--gold)]'
                    }`}
                  >
                    <CircleDot className={`w-5 h-5 ${isRecording ? 'animate-pulse' : ''}`} />
                    {isRecording ? `STOP RECORDING (${recordingTime})` : 'START LOCAL RECORDING (.webm)'}
                  </button>
                  {isRecording && (
                    <p className="text-center text-xs text-red-400 mt-2">Recording in progress — file auto-downloads on stop</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Chat */}
        <div className="w-full md:w-72 border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] flex flex-col group hover:border-[var(--gold)] transition-colors shrink-0">
          <div className="p-3 border-b border-[rgba(212,175,55,0.1)] bg-black/60 flex justify-between items-center">
            <h3 className="font-semibold text-sm flex items-center">
              <MessageSquare className="w-4 h-4 mr-2 text-[var(--gold)]" /> Live Chat
            </h3>
            <button onClick={() => setChat([])} className="text-xs text-gray-500 hover:text-white">Clear</button>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar">
            {chat.map(msg => (
              <div key={msg.id} className="flex gap-2 text-sm">
                <span className="text-[var(--gold)] font-bold shrink-0">{msg.user}:</span>
                <span className="text-gray-300">{msg.text}</span>
              </div>
            ))}
          </div>
          <form
            onSubmit={e => { e.preventDefault(); if (chatInput.trim()) { setChat(prev => [...prev, { id: Date.now(), user: 'You', text: chatInput }]); setChatInput(''); }}}
            className="p-3 border-t border-[rgba(212,175,55,0.1)] flex gap-2"
          >
            <input
              type="text"
              value={chatInput}
              onChange={e => setChatInput(e.target.value)}
              placeholder="Send message..."
              className="flex-1 bg-black/60 border border-gray-700 rounded px-3 py-2 text-sm focus:outline-none focus:border-[var(--gold)] text-white"
            />
            <button type="submit" className="px-3 py-2 bg-[var(--gold)] text-black text-xs font-bold rounded hover:bg-yellow-500">
              Send
            </button>
          </form>
        </div>
      </div>
    </motion.div>
  );
}
