import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { User, Palette, Video, Shield, BellRing, Info, Key, Volume2, Check } from 'lucide-react';

export default function Settings() {
  const [activeSection, setActiveSection] = useState("Profile");
  const [accentColor, setAccentColor] = useState('#D4AF37');
  const [fontSize, setFontSize] = useState(16);
  const [apiKey, setApiKey] = useState('');
  const [apiKeySaved, setApiKeySaved] = useState(false);
  const [musicVolume, setMusicVolume] = useState(0.3);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>('default');
  const [streamQuality, setStreamQuality] = useState('1080p');
  const [streamFps, setStreamFps] = useState('30');
  const [darkMode, setDarkMode] = useState(true);

  const ACCENT_COLORS = [
    { color: '#D4AF37', label: 'Gold' },
    { color: '#22c55e', label: 'Emerald' },
    { color: '#ef4444', label: 'Red' },
    { color: '#3b82f6', label: 'Blue' },
    { color: '#a855f7', label: 'Purple' },
  ];

  useEffect(() => {
    const saved = localStorage.getItem('jjnexus_api_key');
    if (saved) setApiKey(saved);
    const savedColor = localStorage.getItem('accentColor') || '#D4AF37';
    setAccentColor(savedColor);
    document.documentElement.style.setProperty('--gold', savedColor);
    const savedFontSize = localStorage.getItem('fontSize');
    if (savedFontSize) {
      setFontSize(Number(savedFontSize));
      document.documentElement.style.fontSize = savedFontSize + 'px';
    }
    if ('Notification' in window) setNotifPermission(Notification.permission);
  }, []);

  const handleAccentChange = (color: string) => {
    setAccentColor(color);
    document.documentElement.style.setProperty('--gold', color);
    localStorage.setItem('accentColor', color);
  };

  const handleFontSize = (size: number) => {
    setFontSize(size);
    document.documentElement.style.fontSize = size + 'px';
    localStorage.setItem('fontSize', String(size));
  };

  const saveApiKey = () => {
    localStorage.setItem('jjnexus_api_key', apiKey);
    setApiKeySaved(true);
    setTimeout(() => setApiKeySaved(false), 2000);
  };

  const requestNotifications = async () => {
    if (!('Notification' in window)) return;
    const perm = await Notification.requestPermission();
    setNotifPermission(perm);
    if (perm === 'granted') {
      new Notification('JJ Nexus Pro', {
        body: 'Notifications enabled! You will be alerted before high-impact events.',
        icon: '/jj-trades-logo.jpg'
      });
    }
  };

  const updateMusicVolume = (vol: number) => {
    setMusicVolume(vol);
    const audio = document.getElementById('bg-music') as HTMLAudioElement;
    if (audio) audio.volume = vol;
    localStorage.setItem('musicVolume', String(vol));
  };

  const sections = [
    { label: "Profile", icon: User },
    { label: "Appearance", icon: Palette },
    { label: "API & Keys", icon: Key },
    { label: "Stream Settings", icon: Video },
    { label: "Audio", icon: Volume2 },
    { label: "Notifications", icon: BellRing },
    { label: "Risk Defaults", icon: Shield },
    { label: "About", icon: Info },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-4xl mx-auto w-full flex flex-col gap-6"
    >
      <div>
        <h1 className="font-serif text-3xl text-[var(--gold)] font-bold tracking-wider mb-2">SETTINGS</h1>
        <p className="text-[hsl(var(--muted-foreground))]">Configure your JJ Nexus Pro command center</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="space-y-1">
          {sections.map((item) => (
            <button
              key={item.label}
              onClick={() => setActiveSection(item.label)}
              className={`w-full flex items-center px-4 py-3 rounded-lg cursor-pointer transition-colors text-left ${
                activeSection === item.label
                  ? 'bg-[rgba(212,175,55,0.1)] border border-[rgba(212,175,55,0.3)] text-[var(--gold)]'
                  : 'text-[hsl(var(--muted-foreground))] hover:bg-white/5 hover:text-white'
              }`}
            >
              <item.icon className="w-5 h-5 mr-3" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </div>

        <div className="md:col-span-2 space-y-6">
          {activeSection === "Profile" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6">
              <h3 className="text-lg font-bold text-white mb-4 border-b border-[rgba(212,175,55,0.1)] pb-2">Profile</h3>
              <div className="flex items-center gap-6 mb-6">
                <div className="w-24 h-24 rounded-full border-2 border-[var(--gold)] overflow-hidden shadow-[0_0_15px_rgba(212,175,55,0.3)]">
                  <img src="/jj-trades-logo.jpg" alt="Profile" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="text-xl font-bold text-white">JJ Trades</h4>
                  <p className="text-[hsl(var(--muted-foreground))]">admin@jjtrades.pro</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Display Name</label>
                  <input type="text" defaultValue="JJ Trades" className="w-full max-w-md bg-black border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-[var(--gold)]" />
                </div>
                <div>
                  <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Bio</label>
                  <textarea rows={3} defaultValue="Professional Forex Trader & Educator. Building the African trading community." className="w-full max-w-md bg-black border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-[var(--gold)] resize-none" />
                </div>
                <button className="bg-[var(--gold)] text-black px-6 py-2 rounded font-bold hover:bg-yellow-500 transition-colors">Save Changes</button>
              </div>
            </div>
          )}

          {activeSection === "Appearance" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6 space-y-6">
              <h3 className="text-lg font-bold text-white border-b border-[rgba(212,175,55,0.1)] pb-2">Appearance</h3>

              <div>
                <label className="text-sm text-[hsl(var(--muted-foreground))] block mb-3">Accent Color</label>
                <div className="flex gap-3 flex-wrap">
                  {ACCENT_COLORS.map(({ color, label }) => (
                    <button
                      key={color}
                      onClick={() => handleAccentChange(color)}
                      title={label}
                      className={`w-10 h-10 rounded-full transition-all hover:scale-110 flex items-center justify-center ${accentColor === color ? 'ring-2 ring-offset-2 ring-offset-black ring-white scale-110' : ''}`}
                      style={{ backgroundColor: color }}
                    >
                      {accentColor === color && <Check className="w-5 h-5 text-black" />}
                    </button>
                  ))}
                  <input
                    type="color"
                    value={accentColor}
                    onChange={e => handleAccentChange(e.target.value)}
                    className="w-10 h-10 rounded-full cursor-pointer border-2 border-gray-600"
                    title="Custom color"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm text-[hsl(var(--muted-foreground))] block mb-2">
                  Font Size: <span className="text-[var(--gold)] font-mono">{fontSize}px</span>
                </label>
                <input
                  type="range" min="12" max="20" value={fontSize}
                  onChange={e => handleFontSize(Number(e.target.value))}
                  className="w-full max-w-md accent-[var(--gold)]"
                />
                <div className="flex justify-between text-xs text-gray-500 max-w-md mt-1">
                  <span>Compact (12px)</span><span>Default (16px)</span><span>Large (20px)</span>
                </div>
              </div>

              <div>
                <label className="text-sm text-[hsl(var(--muted-foreground))] block mb-3">Theme</label>
                <div className="flex gap-3">
                  {['Dark', 'Light'].map(theme => (
                    <button
                      key={theme}
                      onClick={() => {
                        setDarkMode(theme === 'Dark');
                        document.documentElement.classList.toggle('dark', theme === 'Dark');
                      }}
                      className={`px-6 py-2 rounded font-medium transition-colors ${
                        (darkMode && theme === 'Dark') || (!darkMode && theme === 'Light')
                          ? 'bg-[var(--gold)] text-black'
                          : 'bg-black border border-gray-700 text-gray-400 hover:border-[var(--gold)]'
                      }`}
                    >
                      {theme}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeSection === "API & Keys" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6 space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-[rgba(212,175,55,0.1)] pb-2">API Keys</h3>
              <p className="text-sm text-gray-400">Your Anthropic API key powers the Alchemist AI. It's stored locally in your browser only.</p>
              <div>
                <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Anthropic API Key</label>
                <div className="flex gap-2 max-w-md">
                  <input
                    type="password"
                    value={apiKey}
                    onChange={e => setApiKey(e.target.value)}
                    placeholder="sk-ant-api03-..."
                    className="flex-1 bg-black border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-[var(--gold)] font-mono text-sm"
                  />
                  <button
                    onClick={saveApiKey}
                    className={`px-4 py-2 rounded font-bold text-sm transition-colors flex items-center gap-2 ${apiKeySaved ? 'bg-green-500 text-white' : 'bg-[var(--gold)] text-black hover:bg-yellow-500'}`}
                  >
                    {apiKeySaved ? <><Check className="w-4 h-4" /> Saved!</> : 'Save'}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">Stored in localStorage · Never sent to any third party</p>
              </div>
              <div className="p-4 bg-[rgba(212,175,55,0.05)] border border-[rgba(212,175,55,0.2)] rounded-lg">
                <p className="text-xs text-gray-400">
                  <span className="text-[var(--gold)] font-bold">Current status: </span>
                  {apiKey ? '✅ API key configured (localStorage)' : '⚠️ Using Replit integration (no web search)'}
                </p>
              </div>
            </div>
          )}

          {activeSection === "Stream Settings" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6 space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-[rgba(212,175,55,0.1)] pb-2">Stream Defaults</h3>
              <div>
                <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Default Stream Title</label>
                <input type="text" defaultValue="🔴 LIVE | XAUUSD Snipe Session | JJ Nexus Pro" className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-[var(--gold)]" />
              </div>
              <div>
                <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Resolution</label>
                <select value={streamQuality} onChange={e => { setStreamQuality(e.target.value); localStorage.setItem('streamQuality', e.target.value); }} className="w-full max-w-md bg-black border border-gray-700 rounded px-3 py-2 text-white focus:border-[var(--gold)] outline-none">
                  <option value="4K">4K (3840×2160)</option>
                  <option value="1080p">1080p (1920×1080) — Recommended</option>
                  <option value="720p">720p (1280×720)</option>
                  <option value="480p">480p (854×480)</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Frame Rate</label>
                <select value={streamFps} onChange={e => { setStreamFps(e.target.value); localStorage.setItem('streamFps', e.target.value); }} className="w-full max-w-md bg-black border border-gray-700 rounded px-3 py-2 text-white focus:border-[var(--gold)] outline-none">
                  <option value="60">60 FPS</option>
                  <option value="30">30 FPS — Recommended</option>
                  <option value="24">24 FPS (Cinematic)</option>
                </select>
              </div>
              <p className="text-xs text-gray-500">Settings applied when you next open the Studio and enable camera.</p>
            </div>
          )}

          {activeSection === "Audio" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6 space-y-6">
              <h3 className="text-lg font-bold text-white border-b border-[rgba(212,175,55,0.1)] pb-2">Background Music</h3>
              <p className="text-sm text-gray-400">Use the music button (♪) in the top bar to play/pause. Control volume here.</p>
              <div>
                <label className="text-sm text-[hsl(var(--muted-foreground))] block mb-2">
                  Master Volume: <span className="text-[var(--gold)] font-mono">{Math.round(musicVolume * 100)}%</span>
                </label>
                <input
                  type="range" min="0" max="1" step="0.05" value={musicVolume}
                  onChange={e => updateMusicVolume(Number(e.target.value))}
                  className="w-full max-w-md accent-[var(--gold)]"
                />
              </div>
              <div className="p-4 bg-black/40 rounded-lg border border-[rgba(212,175,55,0.1)]">
                <p className="text-xs text-gray-400 mb-1">Now playing:</p>
                <p className="text-sm text-white font-medium">Ambient Forex Trading Music</p>
                <p className="text-xs text-gray-500">Royalty-free · Auto-loops</p>
              </div>
            </div>
          )}

          {activeSection === "Notifications" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6 space-y-6">
              <h3 className="text-lg font-bold text-white border-b border-[rgba(212,175,55,0.1)] pb-2">Notifications</h3>
              <div className="flex items-center justify-between p-4 bg-black/40 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-white">Browser Notifications</p>
                  <p className="text-xs text-gray-500 mt-1">Alerts before high-impact calendar events</p>
                </div>
                <button
                  onClick={requestNotifications}
                  className={`px-4 py-2 rounded font-bold text-sm transition-colors ${
                    notifPermission === 'granted'
                      ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                      : notifPermission === 'denied'
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30 cursor-not-allowed'
                      : 'bg-[var(--gold)] text-black hover:bg-yellow-500'
                  }`}
                  disabled={notifPermission === 'denied'}
                >
                  {notifPermission === 'granted' ? '✅ Enabled' : notifPermission === 'denied' ? '🚫 Blocked' : 'Enable'}
                </button>
              </div>
              {notifPermission === 'denied' && (
                <p className="text-xs text-red-400">Notifications blocked in browser settings. Please allow them manually.</p>
              )}
              {notifPermission === 'granted' && (
                <div className="space-y-3">
                  {['15 min before HIGH impact events', 'Price alerts when pair hits target', 'New AI analysis available'].map(item => (
                    <label key={item} className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked className="accent-[var(--gold)] w-4 h-4" />
                      <span className="text-sm text-gray-300">{item}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeSection === "Risk Defaults" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6 space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-[rgba(212,175,55,0.1)] pb-2">Risk Defaults</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Default Account Balance ($)</label>
                  <input type="number" defaultValue="10000" className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:border-[var(--gold)] outline-none" />
                </div>
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Max Risk Per Trade (%)</label>
                  <input type="number" defaultValue="1" step="0.5" className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:border-[var(--gold)] outline-none" />
                </div>
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Default R:R Target</label>
                  <select className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:border-[var(--gold)] outline-none">
                    <option>1:1</option><option>1:2</option><option>1:3</option><option>1:4</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Default Strategy</label>
                  <select className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-white focus:border-[var(--gold)] outline-none">
                    <option>Alchemist AI</option><option>SMC</option><option>ICT</option><option>Price Action</option>
                  </select>
                </div>
              </div>
              <button className="bg-[var(--gold)] text-black px-6 py-2 rounded font-bold hover:bg-yellow-500 transition-colors">Save Defaults</button>
            </div>
          )}

          {activeSection === "About" && (
            <div className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-6 space-y-4">
              <h3 className="text-lg font-bold text-white border-b border-[rgba(212,175,55,0.1)] pb-2">About JJ Nexus Pro</h3>
              <div className="flex items-center gap-4">
                <img src="/jj-trades-logo.jpg" alt="Logo" className="w-16 h-16 rounded-full border-2 border-[var(--gold)]" />
                <div>
                  <h4 className="text-[var(--gold)] font-serif font-bold text-xl">JJ NEXUS PRO</h4>
                  <p className="text-gray-400 text-sm">The Ultimate Trading Command Center</p>
                  <p className="text-gray-500 text-xs mt-1">Version 2.0.0 · The Debug Squad · 2026</p>
                </div>
              </div>
              <div className="space-y-2 text-sm text-gray-400">
                <p>• AI: Powered by Claude (Anthropic) with live web search</p>
                <p>• Streaming: Real WebRTC via browser APIs</p>
                <p>• Data: PostgreSQL persistence via Drizzle ORM</p>
                <p>• Built for JJ Trades community</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
