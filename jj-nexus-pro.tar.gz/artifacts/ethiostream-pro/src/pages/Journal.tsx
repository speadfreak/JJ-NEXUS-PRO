import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, BookOpen, Target, Crosshair, BarChart2, Brain, Trash2, Edit2, CheckCircle2 } from 'lucide-react';

export default function Journal() {
  const [entries, setEntries] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [stats, setStats] = useState<any>({ winRate: 0, totalTrades: 0, averageRR: 0, netPips: 0, winCount: 0, lossCount: 0 });
  const [isLoading, setIsLoading] = useState(true);
  
  // AI Insights state
  const [insights, setInsights] = useState("");
  const [isInsightLoading, setIsInsightLoading] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    pair: "XAUUSD", direction: "BUY", entryPrice: "", stopLoss: "", takeProfit: "", strategy: "Alchemist AI", notes: ""
  });

  const fetchData = async () => {
    try {
      setIsLoading(true);
      const [tradesRes, statsRes] = await Promise.all([
        fetch("/api/journal/trades"),
        fetch("/api/journal/stats")
      ]);
      const trades = await tradesRes.json();
      const statsData = await statsRes.json();
      setEntries(trades);
      setStats(statsData);
    } catch (err) {
      console.error("Failed to fetch journal data", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddTrade = async () => {
    if (!formData.entryPrice) return;
    
    // Calculate mock pips/rr if not provided
    const entry = Number(formData.entryPrice);
    const sl = Number(formData.stopLoss);
    const tp = Number(formData.takeProfit);
    const isBuy = formData.direction === "BUY";
    
    const pips = isBuy ? (tp - entry) * 100 : (entry - tp) * 100;
    const rr = Math.abs((tp - entry) / (entry - sl)).toFixed(1);

    try {
      await fetch("/api/journal/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          date: new Date().toISOString(),
          status: "closed",
          result: Math.random() > 0.4 ? "WIN" : "LOSS", // random outcome for demo if not specified
          pips: Math.random() > 0.4 ? Math.abs(pips || 50) : -Math.abs(pips || 30),
          rr: `1:${rr || 2.0}`
        })
      });
      setShowForm(false);
      setFormData({ pair: "XAUUSD", direction: "BUY", entryPrice: "", stopLoss: "", takeProfit: "", strategy: "Alchemist AI", notes: "" });
      fetchData();
    } catch (err) {
      console.error("Failed to add trade", err);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Delete this trade?")) return;
    try {
      await fetch(`/api/journal/trades/${id}`, { method: "DELETE" });
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const getAiInsights = async () => {
    setIsInsightLoading(true);
    setInsights("");
    
    try {
      const response = await fetch("/api/journal/insights");
      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const text = decoder.decode(value);
        const lines = text.split("\n");
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) {
                setIsInsightLoading(false);
                return;
              }
              if (data.content) {
                setInsights(prev => prev + data.content);
              }
            } catch {}
          }
        }
      }
    } catch (err) {
      console.error(err);
    }
    setIsInsightLoading(false);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex flex-col h-full gap-4 max-w-[1600px] mx-auto w-full"
    >
      {/* Top Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 shrink-0">
        {[
          { label: "Win Rate", value: `${Math.round(stats.winRate)}%`, icon: Target, color: "text-[var(--gold)]" },
          { label: "Total Trades", value: stats.totalTrades, icon: BookOpen, color: "text-white" },
          { label: "Average R:R", value: `1:${stats.averageRR ?? 0}`, icon: Crosshair, color: "text-blue-400" },
          { label: "Net Pips", value: (stats.netPips > 0 ? '+' : '') + Math.round(stats.netPips), icon: BarChart2, color: stats.netPips > 0 ? "text-green-500" : "text-red-500" },
          { label: "Win / Loss", value: `${stats.winCount} / ${stats.lossCount}`, icon: CheckCircle2, color: "text-gray-300" },
        ].map((s, i) => (
          <div key={i} className="bg-[hsl(var(--card))] border border-[rgba(212,175,55,0.2)] rounded-lg p-4 flex flex-col items-center justify-center text-center group hover:border-[var(--gold)] transition-colors shadow-md">
            <s.icon className={`w-6 h-6 mb-3 ${s.color} opacity-70 group-hover:opacity-100 transition-opacity`} />
            <span className="text-xs text-[hsl(var(--muted-foreground))] uppercase tracking-widest mb-1 font-semibold">{s.label}</span>
            <span className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</span>
          </div>
        ))}
      </div>

      <div className="flex-1 flex flex-col xl:flex-row gap-4 min-h-0">
        {/* Main Table Area */}
        <div className="flex-[3] border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] flex flex-col overflow-hidden relative group hover:border-[var(--gold)] transition-colors shadow-lg">
          <div className="p-5 border-b border-[rgba(212,175,55,0.1)] bg-black/80 flex justify-between items-center shrink-0">
            <div>
              <h2 className="font-serif text-xl font-bold text-[var(--gold)] tracking-wider">TRADE LOG</h2>
              <p className="text-xs text-gray-500 font-mono mt-1">Synchronized with DB</p>
            </div>
            <button 
              onClick={() => setShowForm(!showForm)}
              className={`px-5 py-2 rounded text-sm font-bold flex items-center transition-colors active:scale-95 ${
                showForm ? 'bg-gray-800 text-white hover:bg-gray-700' : 'bg-[var(--gold)] text-black hover:bg-yellow-500 shadow-[0_0_15px_rgba(212,175,55,0.3)]'
              }`}
            >
              <Plus className={`w-4 h-4 mr-2 transition-transform ${showForm ? 'rotate-45' : ''}`} /> 
              {showForm ? 'CANCEL' : 'LOG TRADE'}
            </button>
          </div>

          <AnimatePresence>
            {showForm && (
              <motion.div 
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="bg-black/90 border-b border-[rgba(212,175,55,0.2)] overflow-hidden shrink-0"
              >
                <div className="p-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-4">
                    <div className="col-span-2 md:col-span-1">
                      <label className="text-xs text-gray-400 block mb-1 font-semibold uppercase">Pair</label>
                      <select value={formData.pair} onChange={e=>setFormData({...formData, pair: e.target.value})} className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm font-bold text-white focus:border-[var(--gold)] outline-none">
                        <option>XAUUSD</option>
                        <option>EURUSD</option>
                        <option>GBPUSD</option>
                        <option>BTCUSD</option>
                      </select>
                    </div>
                    <div className="col-span-2 md:col-span-1">
                      <label className="text-xs text-gray-400 block mb-1 font-semibold uppercase">Direction</label>
                      <select value={formData.direction} onChange={e=>setFormData({...formData, direction: e.target.value})} className={`w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm font-bold outline-none ${formData.direction === 'BUY' ? 'text-green-500' : 'text-red-500'}`}>
                        <option>BUY</option>
                        <option>SELL</option>
                      </select>
                    </div>
                    <div className="col-span-2 md:col-span-1">
                      <label className="text-xs text-gray-400 block mb-1 font-semibold uppercase">Entry</label>
                      <input value={formData.entryPrice} onChange={e=>setFormData({...formData, entryPrice: e.target.value})} type="number" placeholder="e.g. 2024.15" className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm font-mono text-white focus:border-[var(--gold)] outline-none" />
                    </div>
                    <div className="col-span-2 md:col-span-1">
                      <label className="text-xs text-gray-400 block mb-1 font-semibold uppercase">Stop Loss</label>
                      <input value={formData.stopLoss} onChange={e=>setFormData({...formData, stopLoss: e.target.value})} type="number" className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm font-mono text-white focus:border-[var(--gold)] outline-none" />
                    </div>
                    <div className="col-span-2 md:col-span-1">
                      <label className="text-xs text-gray-400 block mb-1 font-semibold uppercase">Target</label>
                      <input value={formData.takeProfit} onChange={e=>setFormData({...formData, takeProfit: e.target.value})} type="number" className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm font-mono text-white focus:border-[var(--gold)] outline-none" />
                    </div>
                    <div className="col-span-2 md:col-span-1">
                      <label className="text-xs text-gray-400 block mb-1 font-semibold uppercase">Strategy</label>
                      <select value={formData.strategy} onChange={e=>setFormData({...formData, strategy: e.target.value})} className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm text-white focus:border-[var(--gold)] outline-none">
                        <option>Alchemist AI</option>
                        <option>SMC</option>
                        <option>Price Action</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-gray-800">
                    <button onClick={handleAddTrade} className="bg-[var(--gold)] text-black px-8 py-2 rounded text-sm font-bold hover:bg-yellow-500 transition-colors shadow-[0_0_10px_rgba(212,175,55,0.2)]">
                      SAVE ENTRY TO DB
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex-1 overflow-auto custom-scrollbar">
            {isLoading ? (
              <div className="flex justify-center items-center h-full text-[var(--gold)]">
                <Brain className="w-8 h-8 animate-pulse mr-3" /> Loading Trades...
              </div>
            ) : entries.length === 0 ? (
              <div className="flex flex-col justify-center items-center h-full text-gray-500">
                <BookOpen className="w-16 h-16 opacity-20 mb-4" />
                <p>No trades logged yet.</p>
              </div>
            ) : (
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-[hsl(var(--muted-foreground))] uppercase bg-black/60 sticky top-0 z-10 backdrop-blur-md shadow-sm">
                  <tr>
                    <th className="px-6 py-4 font-bold tracking-wider">Date</th>
                    <th className="px-6 py-4 font-bold tracking-wider">Pair</th>
                    <th className="px-6 py-4 font-bold tracking-wider">Dir</th>
                    <th className="px-6 py-4 font-bold tracking-wider text-right">Entry</th>
                    <th className="px-6 py-4 font-bold tracking-wider text-right">SL</th>
                    <th className="px-6 py-4 font-bold tracking-wider text-right">TP</th>
                    <th className="px-6 py-4 font-bold tracking-wider text-right">Pips</th>
                    <th className="px-6 py-4 font-bold tracking-wider text-center">R:R</th>
                    <th className="px-6 py-4 font-bold tracking-wider text-center">Result</th>
                    <th className="px-6 py-4 text-center"></th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((t, i) => (
                    <motion.tr 
                      key={t.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className={`border-b border-[rgba(212,175,55,0.05)] hover:bg-white/5 transition-colors group/row ${
                        t.result === 'WIN' ? 'bg-green-500/[0.03]' : t.result === 'LOSS' ? 'bg-red-500/[0.03]' : ''
                      }`}
                    >
                      <td className="px-6 py-4 text-gray-400 font-mono text-xs">{new Date(t.date).toLocaleDateString()}</td>
                      <td className="px-6 py-4 font-bold text-white text-base tracking-wide">{t.pair}</td>
                      <td className={`px-6 py-4 font-bold ${t.direction === 'BUY' ? 'text-green-500' : 'text-red-500'}`}>{t.direction}</td>
                      <td className="px-6 py-4 text-right font-mono text-white">{t.entryPrice || t.entry}</td>
                      <td className="px-6 py-4 text-right font-mono text-red-400/80">{t.stopLoss || t.stop}</td>
                      <td className="px-6 py-4 text-right font-mono text-green-400/80">{t.takeProfit || t.target}</td>
                      <td className={`px-6 py-4 text-right font-mono font-bold text-lg ${t.pips > 0 ? 'text-green-500' : t.pips < 0 ? 'text-red-500' : 'text-gray-400'}`}>
                        {t.pips > 0 ? '+' : ''}{Math.round(t.pips)}
                      </td>
                      <td className="px-6 py-4 text-center font-mono text-gray-300">{t.rr}</td>
                      <td className="px-6 py-4 text-center">
                        <span className={`text-xs px-3 py-1.5 rounded-full font-bold tracking-wider ${
                          t.result === 'WIN' ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 
                          t.result === 'LOSS' ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 
                          'bg-gray-500/20 text-gray-400 border border-gray-500/30'
                        }`}>
                          {t.result || 'OPEN'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button onClick={() => handleDelete(t.id)} className="text-gray-500 hover:text-red-500 opacity-0 group-hover/row:opacity-100 transition-all p-2">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="w-full xl:w-96 flex flex-col gap-4 shrink-0">
          
          {/* AI Insights Button */}
          <button 
            onClick={getAiInsights}
            disabled={isInsightLoading}
            className="w-full bg-gradient-to-r from-black via-[rgba(212,175,55,0.1)] to-black border border-[var(--gold)] text-[var(--gold)] p-4 rounded-lg font-serif font-bold text-lg flex justify-center items-center tracking-widest hover:bg-[rgba(212,175,55,0.15)] transition-all shadow-[0_0_15px_rgba(212,175,55,0.2)] disabled:opacity-50"
          >
            {isInsightLoading ? <Brain className="w-6 h-6 mr-3 animate-spin" /> : <Brain className="w-6 h-6 mr-3" />}
            {isInsightLoading ? 'ANALYZING DB...' : 'GENERATE AI INSIGHTS'}
          </button>

          {/* AI Insights Card */}
          <div className="flex-1 border border-[var(--gold)] rounded-lg bg-gradient-to-b from-[rgba(212,175,55,0.08)] to-black/90 p-5 relative overflow-hidden min-h-[300px]">
            <div className="absolute top-0 right-0 p-4 opacity-5">
              <Brain className="w-48 h-48 text-[var(--gold)]" />
            </div>
            
            <div className="relative z-10 h-full flex flex-col">
              {insights ? (
                <div className="space-y-4">
                  <div className="font-mono text-sm leading-relaxed text-gray-300 whitespace-pre-wrap">
                    {insights}
                    {isInsightLoading && <span className="animate-pulse text-[var(--gold)] ml-1">_</span>}
                  </div>
                </div>
              ) : (
                 <div className="flex-1 flex flex-col items-center justify-center text-center opacity-50">
                    <Brain className="w-12 h-12 mb-3 text-[var(--gold)]" />
                    <p className="text-sm font-mono max-w-[200px]">Click Generate to let Alchemist AI review your trading history for patterns.</p>
                 </div>
              )}
            </div>
          </div>
          
          {/* Mock Calendar */}
          <div className="border border-[rgba(212,175,55,0.2)] rounded-lg bg-black/60 p-5 hover:border-[var(--gold)] transition-colors">
            <h3 className="text-sm font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-widest mb-4 text-center">Activity Heatmap</h3>
            <div className="grid grid-cols-7 gap-1.5">
              {['S','M','T','W','T','F','S'].map((d,i) => <div key={i} className="text-center text-xs text-gray-600 font-bold mb-1">{d}</div>)}
              {Array.from({length: 31}).map((_, i) => {
                let color = "bg-black border-gray-800";
                if (i % 7 === 0 || i % 7 === 6) color = "bg-transparent border-transparent opacity-20"; 
                else if ([13, 11, 7, 5].includes(i)) color = "bg-green-500/30 border-green-500/50 text-green-400";
                else if ([12, 9, 4].includes(i)) color = "bg-red-500/30 border-red-500/50 text-red-400";
                else if (i < 14) color = "bg-gray-800 border-gray-700"; 
                
                return (
                  <div key={i} className={`aspect-square rounded-sm flex items-center justify-center text-xs border transition-colors hover:scale-110 cursor-pointer ${color}`}>
                    {i + 1}
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </motion.div>
  );
}
