import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Search, TrendingUp, TrendingDown, Star, Activity, RefreshCcw } from 'lucide-react';
import { AlertService } from '@/services/AlertService';

interface PairData {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  bid: number;
  ask: number;
  high24: number;
  low24: number;
  momentum: number;
  basePrice: number;
}

const INITIAL_PAIRS: Omit<PairData, 'high24' | 'low24' | 'momentum' | 'basePrice'>[] = [
  { symbol: "XAUUSD", price: 3340.50, change: 0, changePercent: 0, bid: 3340.10, ask: 3340.90 },
  { symbol: "EURUSD", price: 1.0845, change: 0, changePercent: 0, bid: 1.0844, ask: 1.0846 },
  { symbol: "GBPUSD", price: 1.2630, change: 0, changePercent: 0, bid: 1.2629, ask: 1.2631 },
  { symbol: "USDJPY", price: 154.25, change: 0, changePercent: 0, bid: 154.24, ask: 154.26 },
  { symbol: "USDCHF", price: 0.9020, change: 0, changePercent: 0, bid: 0.9019, ask: 0.9021 },
  { symbol: "AUDUSD", price: 0.6480, change: 0, changePercent: 0, bid: 0.6479, ask: 0.6481 },
  { symbol: "NZDUSD", price: 0.6050, change: 0, changePercent: 0, bid: 0.6049, ask: 0.6051 },
  { symbol: "USDCAD", price: 1.3620, change: 0, changePercent: 0, bid: 1.3619, ask: 1.3621 },
  { symbol: "XAGUSD", price: 32.45, change: 0, changePercent: 0, bid: 32.44, ask: 32.46 },
  { symbol: "USOIL", price: 82.30, change: 0, changePercent: 0, bid: 82.28, ask: 82.32 },
  { symbol: "US30", price: 42850.0, change: 0, changePercent: 0, bid: 42848.0, ask: 42852.0 },
  { symbol: "NAS100", price: 21340.0, change: 0, changePercent: 0, bid: 21338.0, ask: 21342.0 },
  { symbol: "SPX500", price: 5780.0, change: 0, changePercent: 0, bid: 5779.0, ask: 5781.0 },
  { symbol: "BTCUSD", price: 97800.0, change: 0, changePercent: 0, bid: 97790.0, ask: 97810.0 },
  { symbol: "GBPJPY", price: 194.85, change: 0, changePercent: 0, bid: 194.83, ask: 194.87 },
];

function initPairs(): PairData[] {
  return INITIAL_PAIRS.map(p => ({
    ...p,
    high24: p.price * (1 + Math.random() * 0.004),
    low24: p.price * (1 - Math.random() * 0.004),
    momentum: (Math.random() - 0.5) * 0.0008,
    basePrice: p.price,
  }));
}

export default function Watchlist() {
  const [pairs, setPairs] = useState<PairData[]>(initPairs);
  const [search, setSearch] = useState("");
  const [liveLoading, setLiveLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchLivePrices = useCallback(async () => {
    setLiveLoading(true);
    try {
      const res = await fetch('/api/proxy/forex-rates');
      if (res.ok) {
        const data = await res.json();
        const rates = data.rates as Record<string, number>;
        setPairs(prev => prev.map(p => {
          let livePrice: number | null = null;
          if (p.symbol === 'EURUSD' && rates.EUR) livePrice = 1 / rates.EUR;
          else if (p.symbol === 'GBPUSD' && rates.GBP) livePrice = 1 / rates.GBP;
          else if (p.symbol === 'USDJPY' && rates.JPY) livePrice = rates.JPY;
          else if (p.symbol === 'USDCHF' && rates.CHF) livePrice = rates.CHF;
          else if (p.symbol === 'AUDUSD' && rates.AUD) livePrice = 1 / rates.AUD;
          else if (p.symbol === 'NZDUSD' && rates.NZD) livePrice = 1 / rates.NZD;
          else if (p.symbol === 'USDCAD' && rates.CAD) livePrice = rates.CAD;

          if (livePrice !== null) {
            const change = livePrice - p.basePrice;
            const changePercent = (change / p.basePrice) * 100;
            const spread = livePrice * 0.00005;
            return {
              ...p,
              price: livePrice,
              change,
              changePercent,
              bid: livePrice - spread,
              ask: livePrice + spread,
              high24: Math.max(p.high24, livePrice),
              low24: Math.min(p.low24, livePrice),
            };
          }
          return p;
        }));
        setLastUpdated(new Date());
      }
    } catch {}
    setLiveLoading(false);
  }, []);

  useEffect(() => {
    fetchLivePrices();
    const liveInterval = setInterval(fetchLivePrices, 30000);
    return () => clearInterval(liveInterval);
  }, [fetchLivePrices]);

  useEffect(() => {
    const simInterval = setInterval(() => {
      setPairs(prev => {
        const updated = prev.map(p => {
          let newMomentum = p.momentum + (Math.random() - 0.5) * 0.0003;
          if (Math.abs(newMomentum) > 0.002) newMomentum *= 0.5;
          if (Math.random() < 0.08) newMomentum = -newMomentum * 0.7;

          const fluctuation = newMomentum * p.price;
          const newPrice = Math.max(0.001, p.price + fluctuation);
          const change = newPrice - p.basePrice;
          const changePercent = (change / p.basePrice) * 100;
          const spread = newPrice * 0.00005;

          return {
            ...p,
            price: newPrice,
            change,
            changePercent,
            bid: newPrice - spread,
            ask: newPrice + spread,
            high24: Math.max(p.high24, newPrice),
            low24: Math.min(p.low24, newPrice),
            momentum: newMomentum,
          };
        });
        const priceMap: Record<string, number> = {};
        updated.forEach(p => { priceMap[p.symbol] = p.price; });
        AlertService.checkPriceAlerts(priceMap);
        return updated;
      });
    }, 2000);
    return () => clearInterval(simInterval);
  }, []);

  const filteredPairs = pairs.filter(p => p.symbol.toLowerCase().includes(search.toLowerCase()));

  const getDecimals = (symbol: string, price: number) => {
    if (symbol.includes('JPY') || symbol.includes('US30') || symbol.includes('NAS') || symbol.includes('SPX') || symbol.includes('GER')) return 1;
    if (price > 1000) return 2;
    if (price < 10) return 5;
    return 4;
  };

  const formatPrice = (symbol: string, price: number) => price.toFixed(getDecimals(symbol, price));

  const generateSparkline = (isPositive: boolean, symbol: string) => {
    let path = "M 0 20 ";
    let y = 20;
    const seed = symbol.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
    for (let x = 10; x <= 100; x += 10) {
      const r = Math.sin(seed + x * 0.3) * 0.3 + (Math.random() - (isPositive ? 0.42 : 0.58)) * 8;
      y = Math.max(3, Math.min(37, y + r));
      path += `L ${x} ${y} `;
    }
    return path;
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex flex-col h-full gap-4 max-w-[1600px] mx-auto w-full"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[hsl(var(--card))] p-6 rounded-lg border border-[rgba(212,175,55,0.2)] relative overflow-hidden shrink-0">
        <div className="absolute inset-0 bg-gradient-to-r from-[rgba(212,175,55,0.05)] to-transparent pointer-events-none" />
        <div className="relative z-10">
          <h1 className="font-serif text-3xl text-[var(--gold)] font-bold tracking-wider flex items-center">
            <Activity className="w-8 h-8 mr-3 opacity-80" />
            INSTITUTIONAL MARKET WATCH
          </h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))] mt-1">
            Live interbank pricing · 
            {lastUpdated ? ` Updated ${lastUpdated.toLocaleTimeString()}` : ' Connecting...'}
          </p>
        </div>
        <div className="flex items-center gap-3 relative z-10">
          <button
            onClick={fetchLivePrices}
            disabled={liveLoading}
            title="Refresh live prices"
            className="p-2 bg-[rgba(212,175,55,0.1)] border border-[rgba(212,175,55,0.3)] rounded-lg text-[var(--gold)] hover:bg-[rgba(212,175,55,0.2)] transition-colors disabled:opacity-50"
          >
            <RefreshCcw className={`w-4 h-4 ${liveLoading ? 'animate-spin' : ''}`} />
          </button>
          <div className="relative w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search pairs..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-black/60 border border-[rgba(212,175,55,0.3)] rounded-full pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-[var(--gold)] transition-all"
            />
          </div>
        </div>
      </div>

      <div className="flex-1 border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] overflow-hidden flex flex-col shadow-lg">
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-sm text-left whitespace-nowrap">
            <thead className="text-xs text-[var(--gold)] uppercase bg-black/80 border-b border-[rgba(212,175,55,0.2)] sticky top-0 z-20 backdrop-blur-md">
              <tr>
                <th className="px-6 py-4 font-bold tracking-wider">Symbol</th>
                <th className="px-6 py-4 font-bold tracking-wider text-right">Price</th>
                <th className="px-6 py-4 font-bold tracking-wider text-right">Change</th>
                <th className="px-6 py-4 font-bold tracking-wider text-right">Bid</th>
                <th className="px-6 py-4 font-bold tracking-wider text-right">Ask</th>
                <th className="px-6 py-4 font-bold tracking-wider text-right">24h High</th>
                <th className="px-6 py-4 font-bold tracking-wider text-right">24h Low</th>
                <th className="px-6 py-4 font-bold tracking-wider text-center">Trend</th>
                <th className="px-6 py-4 font-bold tracking-wider text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredPairs.map((p, i) => {
                const isPositive = p.change >= 0;
                const rowBg = isPositive ? 'hover:bg-green-500/5' : 'hover:bg-red-500/5';

                return (
                  <motion.tr
                    key={p.symbol}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.02 }}
                    className={`border-b border-[rgba(212,175,55,0.05)] ${rowBg} transition-colors group/row cursor-pointer`}
                  >
                    <td className="px-6 py-4 font-bold text-white">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 mr-2 text-gray-600 group-hover/row:text-[var(--gold)] transition-colors" />
                        {p.symbol}
                      </div>
                    </td>
                    <td className={`px-6 py-4 text-right font-mono text-base font-bold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
                      {formatPrice(p.symbol, p.price)}
                    </td>
                    <td className={`px-6 py-4 text-right font-mono ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                      <div className="flex items-center justify-end gap-1">
                        {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {p.change >= 0 ? '+' : ''}{formatPrice(p.symbol, p.change)}
                        <span className="text-xs opacity-80">({Math.abs(p.changePercent).toFixed(2)}%)</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-gray-400">{formatPrice(p.symbol, p.bid)}</td>
                    <td className="px-6 py-4 text-right font-mono text-gray-400">{formatPrice(p.symbol, p.ask)}</td>
                    <td className="px-6 py-4 text-right font-mono text-gray-300">{formatPrice(p.symbol, p.high24)}</td>
                    <td className="px-6 py-4 text-right font-mono text-gray-300">{formatPrice(p.symbol, p.low24)}</td>
                    <td className="px-6 py-4 w-28">
                      <svg width="100" height="40" className="mx-auto overflow-visible">
                        <path
                          d={generateSparkline(isPositive, p.symbol)}
                          fill="none"
                          stroke={isPositive ? "#22c55e" : "#ef4444"}
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="opacity-70 group-hover/row:opacity-100 transition-opacity"
                        />
                      </svg>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <a
                        href="/alchemist"
                        className="bg-transparent border border-[var(--gold)] text-[var(--gold)] px-3 py-1.5 rounded text-xs font-bold hover:bg-[var(--gold)] hover:text-black transition-all opacity-0 group-hover/row:opacity-100 active:scale-95 inline-flex items-center gap-1"
                      >
                        TO CHART
                      </a>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="p-3 border-t border-[rgba(212,175,55,0.1)] text-xs text-gray-600 font-mono text-center">
          Major pairs: Frankfurter API · Others: simulated · Refresh every 30s
        </div>
      </div>
    </motion.div>
  );
}
