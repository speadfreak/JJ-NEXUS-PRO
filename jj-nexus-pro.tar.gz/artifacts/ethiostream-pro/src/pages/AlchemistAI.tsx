import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Activity, TrendingUp, TrendingDown, RefreshCcw, Crosshair, Clock, ShieldCheck, DollarSign, Calendar, Send } from 'lucide-react';
import { ECONOMIC_CALENDAR } from '@/lib/mockData';
import PairSelector from '@/components/common/PairSelector';
import TradingViewWidget from '@/components/common/TradingViewWidget';

export default function AlchemistAI() {
  const [activeTab, setActiveTab] = useState("Confluence");
  const [score, setScore] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [pair, setPair] = useState("XAUUSD");
  const [timeframe, setTimeframe] = useState("H1");
  const [priceInput, setPriceInput] = useState("2024.15");
  
  // Real API state
  const [confluenceData, setConfluenceData] = useState<any>(null);
  const [forexAnalysisText, setForexAnalysisText] = useState("");
  const [isForexLoading, setIsForexLoading] = useState(false);
  const [newsData, setNewsData] = useState<any>(null);
  
  // AI Chat state
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [isChatStreaming, setIsChatStreaming] = useState(false);
  
  // Risk Calc state
  const [balance, setBalance] = useState("10000");
  const [riskPercent, setRiskPercent] = useState("1.0");
  const [stopLossPips, setStopLossPips] = useState("25");

  // Backtest state
  const [backtestProgress, setBacktestProgress] = useState(0);
  const [isBacktesting, setIsBacktesting] = useState(false);
  const [backtestResults, setBacktestResults] = useState<any>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Risk Calc logic
  const dollarRisk = (Number(balance) || 0) * ((Number(riskPercent) || 0) / 100);
  const lotSize = dollarRisk / ((Number(stopLossPips) || 1) * 10); // approx $10 per pip per lot
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  useEffect(() => {
    // Init chat conversation
    const initChat = async () => {
      try {
        const res = await fetch("/api/anthropic/conversations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: "Alchemist AI Session" })
        });
        const data = await res.json();
        setConversationId(data.id);
        
        // Add initial greeting
        setChatMessages([{
          id: 'initial',
          role: 'assistant',
          content: `Hello! I'm Alchemist AI, your expert forex trading assistant. I'm currently analyzing ${pair} on the ${timeframe} timeframe. How can I help you today?`
        }]);
      } catch (err) {
        console.error("Failed to init chat", err);
      }
    };
    initChat();
    handleConfluenceAnalysis();
  }, []);

  const handleConfluenceAnalysis = async () => {
    setIsGenerating(true);
    setScore(0);
    try {
      const response = await fetch("/api/analysis/confluence", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pair, timeframe, price: Number(priceInput), trend: "bullish" }),
      });
      const data = await response.json();
      setConfluenceData(data);
      
      const targetScore = data.score || 87;
      let current = 0;
      const interval = setInterval(() => {
        current += 2;
        if (current >= targetScore) {
          setScore(targetScore);
          clearInterval(interval);
          setIsGenerating(false);
        } else {
          setScore(current);
        }
      }, 20);
    } catch (err) {
      console.error(err);
      setIsGenerating(false);
      setScore(85); // fallback
    }
  };

  const streamForexAnalysis = async () => {
    setIsForexLoading(true);
    setForexAnalysisText("");
    
    try {
      const response = await fetch("/api/analysis/forex", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pair, timeframe, price: Number(priceInput) }),
      });
      
      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const text = decoder.decode(value);
        const lines = text.split("\n");
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) {
                setIsForexLoading(false);
                return;
              }
              if (data.content) {
                setForexAnalysisText(prev => prev + data.content);
              }
            } catch {}
          }
        }
      }
    } catch (err) {
      console.error(err);
    }
    setIsForexLoading(false);
  };

  const fetchNews = async () => {
    if (newsData) return; // cache
    try {
      const res = await fetch(`/api/analysis/news/${pair}`);
      const data = await res.json();
      setNewsData(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (activeTab === "Fundamental") {
      fetchNews();
    }
  }, [activeTab]);

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !conversationId) return;
    
    const userMsg = chatInput;
    setChatInput("");
    setChatMessages(prev => [...prev, { id: Date.now(), role: 'user', content: userMsg }]);
    
    setIsChatStreaming(true);
    let streamedContent = "";
    
    // Add empty assistant message to stream into
    setChatMessages(prev => [...prev, { id: 'temp-streaming', role: 'assistant', content: "" }]);

    try {
      const response = await fetch(`/api/anthropic/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: userMsg }),
      });
      
      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const text = decoder.decode(value);
        const lines = text.split("\n");
        
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) {
                setIsChatStreaming(false);
                return;
              }
              if (data.content) {
                streamedContent += data.content;
                setChatMessages(prev => prev.map(m => 
                  m.id === 'temp-streaming' ? { ...m, content: streamedContent } : m
                ));
              }
            } catch {}
          }
        }
      }
    } catch (err) {
      console.error(err);
    }
    setIsChatStreaming(false);
  };

  const runBacktest = () => {
    setIsBacktesting(true);
    setBacktestProgress(0);
    setBacktestResults(null);
    
    const interval = setInterval(() => {
      setBacktestProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsBacktesting(false);
          setBacktestResults({
            winRate: "68.5%",
            totalTrades: 142,
            netPips: "+1,840",
            bestTrade: "+210 pips",
            worstTrade: "-45 pips",
            profitFactor: "2.1"
          });
          return 100;
        }
        return prev + Math.floor(Math.random() * 20);
      });
    }, 500);
  };

  const tabs = ["Confluence", "Technical", "Fundamental", "Sentiment", "Backtest"];


  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex flex-col h-full gap-4 max-w-[1600px] mx-auto w-full"
    >
      <div className="flex-1 flex flex-col xl:flex-row gap-4 min-h-0">
        
        {/* Left Column: Chart & Panels */}
        <div className="flex-[2] flex flex-col gap-4 min-h-0">
          
          {/* Large Chart */}
          <div className="flex-1 border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] overflow-hidden flex flex-col group hover:border-[var(--gold)] transition-colors min-h-[400px]">
            <div className="h-12 bg-black/60 border-b border-[rgba(212,175,55,0.1)] flex items-center px-4 shrink-0">
              <h2 className="font-serif font-bold text-[var(--gold)] tracking-wider flex items-center">
                <Brain className="w-5 h-5 mr-2" />
                ALCHEMIST AI ANALYSIS
              </h2>
              <div className="ml-auto flex gap-2">
                <PairSelector value={pair} onChange={setPair} className="text-xs py-1 px-2" />
                <select 
                  value={timeframe} 
                  onChange={e => setTimeframe(e.target.value)}
                  className="bg-black border border-gray-700 rounded px-2 py-1 text-sm text-white focus:outline-none focus:border-[var(--gold)]"
                >
                  <option value="M5">M5</option>
                  <option value="M15">M15</option>
                  <option value="M30">M30</option>
                  <option value="H1">H1</option>
                  <option value="H4">H4</option>
                  <option value="D1">D1</option>
                </select>
              </div>
            </div>
            <div className="flex-1 relative">
              <TradingViewWidget symbol={pair} />
            </div>
          </div>

          {/* Analysis Tabs Area */}
          <div className="h-[400px] flex flex-col border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] overflow-hidden group hover:border-[var(--gold)] transition-colors shrink-0">
            <div className="flex border-b border-[rgba(212,175,55,0.1)] bg-black/60 shrink-0 overflow-x-auto custom-scrollbar">
              {tabs.map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    activeTab === tab ? 'text-[var(--gold)] border-b-2 border-[var(--gold)] bg-white/5' : 'text-[hsl(var(--muted-foreground))] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar relative">
              <AnimatePresence mode="wait">
                {activeTab === "Confluence" && (
                  <motion.div 
                    key="confluence"
                    initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="grid grid-cols-1 md:grid-cols-2 gap-6"
                  >
                    <div className="flex flex-col items-center justify-center p-6 bg-black/40 rounded-lg border border-[rgba(212,175,55,0.1)] relative overflow-hidden">
                      {isGenerating && (
                        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center z-10">
                          <RefreshCcw className="w-8 h-8 text-[var(--gold)] animate-spin mb-4" />
                          <span className="text-[var(--gold)] font-mono text-sm">Processing Neural Nets...</span>
                        </div>
                      )}
                      <h3 className="text-[hsl(var(--muted-foreground))] uppercase tracking-widest text-sm mb-4">Overall Confluence</h3>
                      <div className="relative w-32 h-32 flex items-center justify-center mb-2">
                        <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                          <circle cx="64" cy="64" r="56" fill="none" stroke="rgba(212,175,55,0.1)" strokeWidth="10" />
                          <circle 
                            cx="64" cy="64" r="56" fill="none" stroke="var(--gold)" strokeWidth="10"
                            strokeDasharray="351.8"
                            strokeDashoffset={351.8 - (351.8 * score) / 100}
                            className="transition-all duration-100 ease-out"
                          />
                        </svg>
                        <div className="text-4xl font-bold text-white shadow-[var(--gold)] drop-shadow-lg">{score}</div>
                      </div>
                      <div className={`font-bold text-lg flex items-center mt-2 ${confluenceData?.bias === 'BEARISH' ? 'text-red-500' : 'text-green-500'}`}>
                        {confluenceData?.bias === 'BEARISH' ? <TrendingDown className="w-5 h-5 mr-2" /> : <TrendingUp className="w-5 h-5 mr-2" />} 
                        {confluenceData?.bias === 'BEARISH' ? 'PROBABLE SHORT' : 'HIGH PROBABILITY LONG'}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex justify-between items-center mb-2">
                        <h4 className="text-sm font-semibold uppercase text-[hsl(var(--muted-foreground))]">Factor Breakdown</h4>
                        <button onClick={handleConfluenceAnalysis} className="text-xs bg-[rgba(212,175,55,0.2)] text-[var(--gold)] px-3 py-1 rounded hover:bg-[var(--gold)] hover:text-black transition-colors">
                          RE-ANALYZE
                        </button>
                      </div>
                      {[
                        { label: "Market Structure (HTF)", val: confluenceData?.factors?.structure || 88, color: "bg-green-500" },
                        { label: "Order Block Proximity", val: confluenceData?.factors?.orderBlocks || 82, color: "bg-green-500" },
                        { label: "Momentum Indicators", val: confluenceData?.factors?.momentum || 65, color: "bg-yellow-500" },
                        { label: "Fundamental Bias", val: confluenceData?.factors?.fundamentals || 75, color: "bg-[var(--gold)]" },
                      ].map(f => (
                        <div key={f.label} className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>{f.label}</span>
                            <span className="font-mono">{f.val}%</span>
                          </div>
                          <div className="h-1.5 w-full bg-black rounded-full overflow-hidden">
                            <div className={`h-full ${f.color}`} style={{ width: `${f.val}%` }} />
                          </div>
                        </div>
                      ))}
                      
                      {confluenceData?.tradeIdea && (
                        <div className="mt-4 p-3 border border-[var(--gold)] rounded bg-[rgba(212,175,55,0.05)] text-sm">
                          <div className="grid grid-cols-3 gap-2 text-center">
                            <div><span className="block text-[10px] text-gray-400">ENTRY</span><span className="font-bold">{confluenceData.tradeIdea.entry}</span></div>
                            <div><span className="block text-[10px] text-gray-400">STOP</span><span className="font-bold text-red-500">{confluenceData.tradeIdea.stopLoss}</span></div>
                            <div><span className="block text-[10px] text-gray-400">TARGET</span><span className="font-bold text-green-500">{confluenceData.tradeIdea.takeProfit}</span></div>
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                {activeTab === "Technical" && (
                  <motion.div key="tech" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="font-bold text-[var(--gold)] flex items-center">
                        <Crosshair className="w-4 h-4 mr-2"/> DEEP TECHNICAL ANALYSIS
                      </h3>
                      <button 
                        onClick={streamForexAnalysis}
                        disabled={isForexLoading}
                        className="bg-[var(--gold)] text-black px-4 py-1.5 rounded text-xs font-bold hover:bg-yellow-500 transition-colors disabled:opacity-50"
                      >
                        {isForexLoading ? 'ANALYZING...' : 'RUN FULL ANALYSIS'}
                      </button>
                    </div>
                    
                    <div className="p-4 bg-black/60 rounded-lg border border-[rgba(212,175,55,0.1)] min-h-[200px] font-mono text-sm leading-relaxed text-gray-300">
                      {forexAnalysisText ? (
                        <div dangerouslySetInnerHTML={{ 
                          __html: forexAnalysisText.replace(/\*\*(.*?)\*\*/g, '<strong class="text-[var(--gold)]">$1</strong>').replace(/\n/g, '<br/>')
                        }} />
                      ) : (
                        <div className="flex items-center justify-center h-full text-gray-500 opacity-50">
                          Click 'Run Full Analysis' to generate real-time AI technical report
                        </div>
                      )}
                      {isForexLoading && <span className="animate-pulse text-[var(--gold)] ml-1">_</span>}
                    </div>
                  </motion.div>
                )}

                {activeTab === "Fundamental" && (
                  <motion.div key="fund" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                    {newsData ? (
                      <>
                        <div className="p-4 bg-[rgba(212,175,55,0.05)] border border-[var(--gold)] rounded-lg">
                          <h4 className="text-sm font-bold text-[var(--gold)] mb-2">AI Macro Summary</h4>
                          <p className="text-sm text-gray-300 leading-relaxed">{newsData.summary || "No recent news detected."}</p>
                        </div>
                        <div>
                          <h4 className="text-sm font-semibold uppercase text-[hsl(var(--muted-foreground))] mb-3 flex items-center">
                            <Calendar className="w-4 h-4 mr-2" /> Key Events
                          </h4>
                          <div className="space-y-2">
                            {(newsData.events || ECONOMIC_CALENDAR).map((ev: any, i: number) => (
                              <div key={i} className="p-3 rounded-lg bg-black/40 border border-[rgba(212,175,55,0.1)] flex justify-between items-center">
                                <div>
                                  <span className="font-medium text-sm block text-white">{ev.event || ev.title}</span>
                                  <span className="text-xs text-gray-500">{ev.time || ev.date}</span>
                                </div>
                                <span className={`text-xs px-2 py-1 rounded font-bold ${
                                  (ev.impact || ev.sentiment) === 'HIGH' || (ev.impact || ev.sentiment) === 'BEARISH' ? 'bg-red-500/20 text-red-500' : 'bg-green-500/20 text-green-500'
                                }`}>
                                  {ev.impact || ev.sentiment}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </>
                    ) : (
                      <div className="flex justify-center items-center h-40">
                        <RefreshCcw className="w-6 h-6 animate-spin text-[var(--gold)]" />
                      </div>
                    )}
                  </motion.div>
                )}

                {activeTab === "Backtest" && (
                  <motion.div key="backtest" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="text-xs text-gray-400 block mb-1">Strategy</label>
                        <select className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm text-white focus:border-[var(--gold)] outline-none">
                          <option>Alchemist Neural (AI)</option>
                          <option>Smart Money Concepts</option>
                          <option>ICT Silver Bullet</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-xs text-gray-400 block mb-1">Date Range</label>
                        <select className="w-full bg-black border border-gray-700 rounded px-3 py-2 text-sm text-white focus:border-[var(--gold)] outline-none">
                          <option>Last 3 Months</option>
                          <option>Last 6 Months</option>
                          <option>Year to Date</option>
                        </select>
                      </div>
                      <div className="flex items-end">
                        <button 
                          onClick={runBacktest}
                          disabled={isBacktesting}
                          className="w-full bg-[var(--gold)] text-black px-4 py-2 rounded text-sm font-bold hover:bg-yellow-500 transition-colors disabled:opacity-50"
                        >
                          {isBacktesting ? 'SIMULATING...' : 'RUN AI BACKTEST'}
                        </button>
                      </div>
                    </div>

                    {isBacktesting && (
                      <div className="mt-8">
                        <div className="flex justify-between text-xs text-[var(--gold)] font-mono mb-2">
                          <span>Processing historical tick data...</span>
                          <span>{backtestProgress}%</span>
                        </div>
                        <div className="h-2 w-full bg-black rounded-full overflow-hidden">
                          <div className="h-full bg-[var(--gold)] transition-all duration-300" style={{ width: `${backtestProgress}%` }} />
                        </div>
                      </div>
                    )}

                    {backtestResults && !isBacktesting && (
                      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-6">
                        {Object.entries(backtestResults).map(([key, val]) => (
                          <div key={key} className="bg-black/40 p-4 rounded-lg border border-[rgba(212,175,55,0.1)] text-center">
                            <span className="text-xs text-gray-500 uppercase tracking-wider block mb-1">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                            <span className={`text-xl font-bold font-mono ${typeof val === 'string' && val.includes('-') ? 'text-red-500' : typeof val === 'string' && val.includes('+') ? 'text-green-500' : 'text-white'}`}>{val as React.ReactNode}</span>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Right Column: Chat & Risk */}
        <div className="w-full xl:w-96 flex flex-col gap-4 shrink-0">
          
          {/* AI Chat Panel */}
          <div className="flex-1 flex flex-col border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] overflow-hidden group hover:border-[var(--gold)] transition-colors min-h-[400px]">
            <div className="h-12 bg-black/60 border-b border-[rgba(212,175,55,0.1)] flex items-center px-4 shrink-0">
              <h2 className="font-serif font-bold text-[var(--gold)] tracking-wider flex items-center">
                <Brain className="w-4 h-4 mr-2" /> AI TRADING ASST
              </h2>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar bg-black/20">
              {chatMessages.map(msg => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] rounded-lg p-3 text-sm leading-relaxed ${
                    msg.role === 'user' 
                      ? 'bg-[var(--gold)] text-black rounded-tr-none' 
                      : 'bg-[rgba(212,175,55,0.1)] border border-[rgba(212,175,55,0.2)] text-gray-200 rounded-tl-none font-mono'
                  }`}>
                    {msg.content || (msg.id === 'temp-streaming' && <span className="animate-pulse">_</span>)}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            <div className="p-3 border-t border-[rgba(212,175,55,0.1)] bg-black/60">
              <form onSubmit={handleSendChat} className="flex gap-2">
                <input 
                  type="text" 
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  placeholder="Ask Alchemist about any pair..." 
                  className="flex-1 bg-black border border-gray-700 rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-[var(--gold)] transition-colors"
                />
                <button type="submit" disabled={isChatStreaming || !chatInput.trim()} className="bg-[var(--gold)] text-black px-3 py-2 rounded flex items-center justify-center hover:bg-yellow-500 transition-colors disabled:opacity-50">
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>

          {/* Risk Calc */}
          <div className="border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] p-4 group hover:border-[var(--gold)] transition-colors shrink-0">
            <h3 className="text-sm font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider mb-4 flex items-center">
              <ShieldCheck className="w-4 h-4 mr-2" /> Live Risk Calculator
            </h3>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Balance ($)</label>
                <input 
                  type="number" 
                  value={balance} 
                  onChange={e => setBalance(e.target.value)}
                  className="w-full bg-black border border-gray-700 rounded px-2 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-[var(--gold)]" 
                />
              </div>
              <div>
                <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Risk %</label>
                <div className="flex gap-2 items-center">
                  <input 
                    type="range" 
                    min="0.5" max="5" step="0.1" 
                    value={riskPercent} 
                    onChange={e => setRiskPercent(e.target.value)}
                    className="w-full accent-[var(--gold)]" 
                  />
                  <span className="text-sm font-mono text-[var(--gold)] w-8">{riskPercent}%</span>
                </div>
              </div>
              <div>
                <label className="text-xs text-[hsl(var(--muted-foreground))] block mb-1">Stop Loss (Pips)</label>
                <input 
                  type="number" 
                  value={stopLossPips} 
                  onChange={e => setStopLossPips(e.target.value)}
                  className="w-full bg-black border border-gray-700 rounded px-2 py-1.5 text-sm font-mono text-white focus:outline-none focus:border-[var(--gold)]" 
                />
              </div>
              <div className="bg-[rgba(212,175,55,0.1)] rounded p-2 border border-[rgba(212,175,55,0.2)] flex flex-col justify-center items-center relative overflow-hidden">
                <span className="text-[10px] text-[var(--gold)] absolute top-1 left-2">Lot Size</span>
                <span className="text-xl font-bold font-mono text-white mt-2">{lotSize.toFixed(2)}</span>
              </div>
            </div>
            <div className="flex justify-between text-xs text-gray-400 border-t border-[rgba(212,175,55,0.1)] pt-2">
              <span>Risk: <strong className="text-red-400 font-mono">${dollarRisk.toFixed(2)}</strong></span>
              <span>Mini: <strong className="text-white font-mono">{(lotSize * 10).toFixed(1)}</strong></span>
              <span>Micro: <strong className="text-white font-mono">{(lotSize * 100).toFixed(0)}</strong></span>
            </div>
          </div>
          
        </div>
      </div>
    </motion.div>
  );
}
