import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, Brain, TrendingUp, TrendingDown, Minus, RefreshCcw, Filter } from 'lucide-react';

interface CalendarEvent {
  title: string;
  country: string;
  date: string;
  impact: string;
  forecast: string;
  previous: string;
  actual: string;
}

interface AIEventAnalysis {
  loading: boolean;
  text: string;
}

const CURRENCY_FLAGS: Record<string, string> = {
  USD: '🇺🇸', EUR: '🇪🇺', GBP: '🇬🇧', JPY: '🇯🇵', AUD: '🇦🇺',
  CAD: '🇨🇦', CHF: '🇨🇭', NZD: '🇳🇿', CNY: '🇨🇳'
};

const HIGH_IMPACT_KEYWORDS = ['NFP', 'Non-Farm', 'CPI', 'FOMC', 'GDP', 'PMI', 'Retail Sales', 'Interest Rate', 'Rate Decision', 'Unemployment'];

export default function EconomicCalendar() {
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCurrency, setSelectedCurrency] = useState<string>('ALL');
  const [selectedImpact, setSelectedImpact] = useState<string>('ALL');
  const [aiAnalysis, setAiAnalysis] = useState<Record<string, AIEventAnalysis>>({});
  const [expandedEvent, setExpandedEvent] = useState<string | null>(null);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const tick = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(tick);
  }, []);

  const fetchCalendar = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/proxy/calendar', {
        headers: { 'Accept': 'application/json' }
      });
      if (!res.ok) throw new Error('Failed to fetch calendar');
      const data: CalendarEvent[] = await res.json();
      const enriched = data.map(ev => ({
        ...ev,
        impact: ev.impact?.toUpperCase() || 'LOW'
      }));
      setEvents(enriched);
    } catch {
      const fallback: CalendarEvent[] = [
        { title: "Non-Farm Payrolls", country: "USD", date: new Date(Date.now() + 86400000).toISOString(), impact: "HIGH", forecast: "175K", previous: "228K", actual: "" },
        { title: "CPI m/m", country: "USD", date: new Date(Date.now() + 172800000).toISOString(), impact: "HIGH", forecast: "0.3%", previous: "0.2%", actual: "" },
        { title: "ECB Rate Decision", country: "EUR", date: new Date(Date.now() + 259200000).toISOString(), impact: "HIGH", forecast: "3.50%", previous: "3.50%", actual: "" },
        { title: "BOE Rate Statement", country: "GBP", date: new Date(Date.now() + 345600000).toISOString(), impact: "HIGH", forecast: "4.75%", previous: "4.75%", actual: "" },
        { title: "Retail Sales m/m", country: "USD", date: new Date(Date.now() + 432000000).toISOString(), impact: "MEDIUM", forecast: "0.4%", previous: "-0.1%", actual: "" },
        { title: "PMI Manufacturing", country: "USD", date: new Date(Date.now() + 518400000).toISOString(), impact: "MEDIUM", forecast: "49.8", previous: "49.0", actual: "" },
        { title: "GDP q/q", country: "EUR", date: new Date(Date.now() - 3600000).toISOString(), impact: "HIGH", forecast: "0.3%", previous: "0.4%", actual: "0.3%" },
        { title: "Unemployment Rate", country: "USD", date: new Date(Date.now() - 7200000).toISOString(), impact: "HIGH", forecast: "4.1%", previous: "4.0%", actual: "4.2%" },
      ];
      setEvents(fallback);
      setError('Using cached data — live feed temporarily unavailable');
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchCalendar();
    const interval = setInterval(fetchCalendar, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetchCalendar]);

  const getCountdown = (dateStr: string) => {
    const eventDate = new Date(dateStr);
    const diff = eventDate.getTime() - now.getTime();
    if (diff <= 0) return null;
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    if (h > 48) return `${Math.floor(h / 24)}d ${h % 24}h`;
    if (h > 0) return `${h}h ${m}m`;
    return `${m}m`;
  };

  const isPast = (dateStr: string) => new Date(dateStr) < now;
  const isHighImpact = (title: string) => HIGH_IMPACT_KEYWORDS.some(k => title.includes(k));

  const getResultColor = (actual: string, forecast: string, title: string) => {
    if (!actual || !forecast) return '';
    const a = parseFloat(actual.replace(/[^0-9.-]/g, ''));
    const f = parseFloat(forecast.replace(/[^0-9.-]/g, ''));
    if (isNaN(a) || isNaN(f)) return 'text-gray-400';
    const isBullish = a > f;
    return isBullish ? 'text-green-400' : 'text-red-400';
  };

  const impactColor = (impact: string) => {
    if (impact === 'HIGH') return 'bg-red-500/20 text-red-400 border-red-500/30';
    if (impact === 'MEDIUM') return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
    return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  };

  const analyzeEvent = async (event: CalendarEvent) => {
    const key = event.title + event.date;
    if (aiAnalysis[key]?.text) {
      setExpandedEvent(expandedEvent === key ? null : key);
      return;
    }
    setExpandedEvent(key);
    setAiAnalysis(prev => ({ ...prev, [key]: { loading: true, text: '' } }));

    try {
      const response = await fetch('/api/analysis/forex', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pair: event.country === 'USD' ? 'XAUUSD' : `${event.country}USD`,
          timeframe: 'H1',
          price: 0,
          bias: '',
          context: `Event: ${event.title} | Forecast: ${event.forecast} | Previous: ${event.previous}${event.actual ? ` | Actual: ${event.actual}` : ''}. Provide event analysis: what this measures, expected USD impact, and how to trade it using current market data.`
        }),
      });

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      let text = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value);
        for (const line of chunk.split('\n')) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) break;
              if (data.content) {
                text += data.content;
                setAiAnalysis(prev => ({ ...prev, [key]: { loading: false, text } }));
              }
            } catch {}
          }
        }
      }
    } catch (err) {
      setAiAnalysis(prev => ({ ...prev, [key]: { loading: false, text: 'Failed to analyze event.' } }));
    }
  };

  const currencies = ['ALL', ...Array.from(new Set(events.map(e => e.country))).sort()];
  const impacts = ['ALL', 'HIGH', 'MEDIUM', 'LOW'];

  const filtered = events.filter(ev => {
    if (selectedCurrency !== 'ALL' && ev.country !== selectedCurrency) return false;
    if (selectedImpact !== 'ALL' && ev.impact !== selectedImpact) return false;
    return true;
  }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const upcoming = filtered.filter(e => !isPast(e.date));
  const past = filtered.filter(e => isPast(e.date)).reverse();

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex flex-col gap-4 max-w-[1400px] mx-auto w-full"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[hsl(var(--card))] p-6 rounded-lg border border-[rgba(212,175,55,0.2)]">
        <div>
          <h1 className="font-serif text-3xl text-[var(--gold)] font-bold tracking-wider flex items-center">
            <Calendar className="w-8 h-8 mr-3 opacity-80" />
            ECONOMIC CALENDAR
          </h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))] mt-1">Live high-impact forex events with AI analysis</p>
          {error && <p className="text-xs text-orange-400 mt-1">{error}</p>}
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-[var(--gold)]" />
            <select
              value={selectedCurrency}
              onChange={e => setSelectedCurrency(e.target.value)}
              className="bg-black border border-gray-700 rounded px-3 py-1.5 text-sm text-white focus:border-[var(--gold)] outline-none"
            >
              {currencies.map(c => <option key={c}>{c}</option>)}
            </select>
            <select
              value={selectedImpact}
              onChange={e => setSelectedImpact(e.target.value)}
              className="bg-black border border-gray-700 rounded px-3 py-1.5 text-sm text-white focus:border-[var(--gold)] outline-none"
            >
              {impacts.map(i => <option key={i}>{i}</option>)}
            </select>
          </div>
          <button
            onClick={fetchCalendar}
            disabled={loading}
            className="bg-[rgba(212,175,55,0.15)] border border-[rgba(212,175,55,0.3)] text-[var(--gold)] px-3 py-1.5 rounded text-sm hover:bg-[rgba(212,175,55,0.25)] transition-colors disabled:opacity-50"
          >
            <RefreshCcw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {loading && events.length === 0 ? (
        <div className="flex items-center justify-center h-64">
          <RefreshCcw className="w-8 h-8 animate-spin text-[var(--gold)]" />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Upcoming */}
          {upcoming.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest text-[var(--gold)] mb-3 flex items-center">
                <Clock className="w-3.5 h-3.5 mr-2" /> UPCOMING EVENTS
              </h2>
              <div className="space-y-2">
                {upcoming.map((ev, i) => {
                  const key = ev.title + ev.date;
                  const countdown = getCountdown(ev.date);
                  const analysis = aiAnalysis[key];
                  const isExpanded = expandedEvent === key;
                  const isHigh = isHighImpact(ev.title) || ev.impact === 'HIGH';

                  return (
                    <motion.div
                      key={key}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className={`rounded-lg border overflow-hidden ${isHigh ? 'border-red-500/30' : 'border-[rgba(212,175,55,0.15)]'} bg-[hsl(var(--card))]`}
                    >
                      <div
                        className="flex flex-col md:flex-row items-start md:items-center gap-3 p-4 cursor-pointer hover:bg-white/5 transition-colors"
                        onClick={() => analyzeEvent(ev)}
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <div className="text-xl shrink-0">{CURRENCY_FLAGS[ev.country] || '🌐'}</div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-white text-sm">{ev.title}</span>
                              {isHigh && <span className="text-xs px-1.5 py-0.5 bg-red-500/20 text-red-400 rounded font-mono">HIGH IMPACT</span>}
                            </div>
                            <div className="flex items-center gap-3 mt-1 text-xs text-gray-500 font-mono">
                              <span>{ev.country}</span>
                              <span>{new Date(ev.date).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 shrink-0">
                          <span className={`text-xs px-2 py-1 rounded border font-bold ${impactColor(ev.impact)}`}>{ev.impact}</span>
                          {countdown && (
                            <div className="text-center">
                              <div className="text-[var(--gold)] font-mono text-sm font-bold">{countdown}</div>
                              <div className="text-xs text-gray-600">until event</div>
                            </div>
                          )}
                          <div className="text-center hidden md:block">
                            <div className="text-xs text-gray-500">Forecast</div>
                            <div className="font-mono text-sm font-bold text-white">{ev.forecast || '—'}</div>
                          </div>
                          <div className="text-center hidden md:block">
                            <div className="text-xs text-gray-500">Previous</div>
                            <div className="font-mono text-sm text-gray-400">{ev.previous || '—'}</div>
                          </div>
                          <button className="text-xs bg-[rgba(212,175,55,0.1)] border border-[rgba(212,175,55,0.3)] text-[var(--gold)] px-3 py-1.5 rounded hover:bg-[rgba(212,175,55,0.2)] transition-colors flex items-center gap-1.5 whitespace-nowrap">
                            <Brain className="w-3 h-3" /> AI Analysis
                          </button>
                        </div>
                      </div>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="border-t border-[rgba(212,175,55,0.1)] overflow-hidden"
                          >
                            <div className="p-4 bg-black/40">
                              {analysis?.loading ? (
                                <div className="flex items-center gap-3 text-[var(--gold)]">
                                  <RefreshCcw className="w-4 h-4 animate-spin" />
                                  <span className="text-sm font-mono">Searching live data for {ev.title}...</span>
                                </div>
                              ) : (
                                <div
                                  className="text-sm text-gray-300 leading-relaxed font-mono"
                                  dangerouslySetInnerHTML={{
                                    __html: (analysis?.text || '').replace(/\*\*(.*?)\*\*/g, '<strong class="text-[var(--gold)]">$1</strong>').replace(/\n/g, '<br/>')
                                  }}
                                />
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Past Events */}
          {past.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-3">RELEASED THIS WEEK</h2>
              <div className="space-y-2">
                {past.slice(0, 10).map((ev, i) => {
                  const resultColor = getResultColor(ev.actual, ev.forecast, ev.title);
                  const beat = resultColor === 'text-green-400';
                  const missed = resultColor === 'text-red-400';

                  return (
                    <div
                      key={ev.title + ev.date + i}
                      className="flex flex-col md:flex-row items-start md:items-center gap-3 p-4 rounded-lg border border-[rgba(212,175,55,0.08)] bg-[hsl(var(--card))] opacity-80"
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="text-xl shrink-0 opacity-60">{CURRENCY_FLAGS[ev.country] || '🌐'}</div>
                        <div className="min-w-0">
                          <span className="font-medium text-gray-400 text-sm">{ev.title}</span>
                          <div className="text-xs text-gray-600 font-mono mt-0.5">
                            {new Date(ev.date).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-6 shrink-0 text-sm">
                        <span className={`text-xs px-2 py-0.5 rounded border font-bold ${impactColor(ev.impact)}`}>{ev.impact}</span>
                        <div className="text-center">
                          <div className="text-xs text-gray-600">Forecast</div>
                          <div className="font-mono text-gray-400">{ev.forecast || '—'}</div>
                        </div>
                        <div className="text-center">
                          <div className="text-xs text-gray-600">Previous</div>
                          <div className="font-mono text-gray-500">{ev.previous || '—'}</div>
                        </div>
                        {ev.actual && (
                          <div className="text-center">
                            <div className="text-xs text-gray-600">Actual</div>
                            <div className={`font-mono font-bold flex items-center gap-1 ${resultColor}`}>
                              {beat ? <TrendingUp className="w-3 h-3" /> : missed ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                              {ev.actual}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
