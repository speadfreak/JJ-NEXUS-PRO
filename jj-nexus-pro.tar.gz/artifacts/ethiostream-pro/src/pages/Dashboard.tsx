import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Activity, Radio, Target, ShieldAlert, Clock, Brain, RefreshCcw, Camera, Monitor } from 'lucide-react';
import { MARKET_SESSIONS } from '@/lib/mockData';
import TradingViewWidget from '@/components/common/TradingViewWidget';
import ChartSymbolSwitcher from '@/components/common/ChartSymbolSwitcher';
import { useCamera } from '@/context/CameraContext';

export default function Dashboard() {
  const { isActive, screenStream, stream } = useCamera();
  const [confluenceScore, setConfluenceScore] = useState(0);
  const [analysisText, setAnalysisText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [textIndex, setTextIndex] = useState(0);
  const [dashboardSymbol, setDashboardSymbol] = useState("XAUUSD");

  const streamIsLive = isActive || !!screenStream;
  const streamLabel = isActive && screenStream ? 'CAM + SCREEN' : isActive ? 'CAMERA LIVE' : screenStream ? 'SCREEN SHARE' : 'IDLE';
  const streamColor = streamIsLive ? 'text-green-400' : 'text-gray-500';

  const getStreamResolution = () => {
    if (stream) {
      const t = stream.getVideoTracks()[0];
      if (t) { const s = t.getSettings(); return `${s.width ?? '?'}×${s.height ?? '?'}`; }
    }
    if (screenStream) {
      const t = screenStream.getVideoTracks()[0];
      if (t) { const s = t.getSettings(); return `${s.width ?? '?'}×${s.height ?? '?'}`; }
    }
    return 'No signal';
  };
  
  const defaultTexts = [
    "Awaiting fresh analysis. Click 'Quick Analysis' to begin.",
    "System ready. Standing by for confluence check.",
    "Monitoring major pairs for volatility spikes."
  ];

  useEffect(() => {
    // Animate score on mount
    const interval = setInterval(() => {
      setConfluenceScore(prev => {
        if (prev < 84) return prev + 1;
        clearInterval(interval);
        return 84;
      });
    }, 20);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (isAnalyzing) return;
    const rotateInterval = setInterval(() => {
      setTextIndex(prev => (prev + 1) % defaultTexts.length);
      setAnalysisText("");
    }, 5000);
    return () => clearInterval(rotateInterval);
  }, [isAnalyzing]);

  useEffect(() => {
    if (isAnalyzing) return;
    const currentText = defaultTexts[textIndex];
    let i = 0;
    const typeInterval = setInterval(() => {
      setAnalysisText(currentText.slice(0, i));
      i++;
      if (i > currentText.length) clearInterval(typeInterval);
    }, 30);
    return () => clearInterval(typeInterval);
  }, [textIndex, isAnalyzing]);

  const handleQuickAnalysis = async () => {
    setIsAnalyzing(true);
    setAnalysisText("");
    setConfluenceScore(0);
    
    try {
      const response = await fetch("/api/analysis/confluence", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pair: "XAUUSD", timeframe: "H1", price: 2015.50, trend: "bullish" }),
      });
      
      const data = await response.json();
      
      // Animate to new score
      const targetScore = data.score || 88;
      let current = 0;
      const scoreInterval = setInterval(() => {
        current += 2;
        if (current >= targetScore) {
          setConfluenceScore(targetScore);
          clearInterval(scoreInterval);
        } else {
          setConfluenceScore(current);
        }
      }, 20);

      // Typewriter the real analysis
      const resultText = data.analysis || "XAUUSD approaching major weekly order block. Institutional sponsorship detected. High probability long setup forming.";
      let i = 0;
      const typeInterval = setInterval(() => {
        setAnalysisText(resultText.slice(0, i));
        i++;
        if (i > resultText.length) {
          clearInterval(typeInterval);
          setIsAnalyzing(false);
        }
      }, 20);
      
    } catch (err) {
      console.error(err);
      setIsAnalyzing(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="flex flex-col h-full gap-4"
    >
      <div className="flex-1 flex flex-col lg:flex-row gap-4 min-h-0">
        {/* TradingView Chart */}
        <div className="flex-1 flex flex-col border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] overflow-hidden shadow-lg relative group transition-all hover:border-[var(--gold)]">
          <div className="h-10 bg-black/60 border-b border-[rgba(212,175,55,0.1)] flex items-center px-4 shrink-0 gap-3">
            <h2 className="font-serif font-bold text-[var(--gold)] tracking-wider">{dashboardSymbol} • H1 • LIVE</h2>
            <ChartSymbolSwitcher currentSymbol={dashboardSymbol} onSymbolChange={setDashboardSymbol} />
            <div className="ml-auto flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              <span className="text-xs text-[hsl(var(--muted-foreground))]">CONNECTED</span>
            </div>
          </div>
          <div className="flex-1 relative">
            <TradingViewWidget symbol={dashboardSymbol} />
          </div>
        </div>

        {/* Alchemist AI Panel */}
        <div className="w-full lg:w-80 flex flex-col gap-4 shrink-0">
          <div className="flex-1 border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] p-4 flex flex-col relative overflow-hidden group hover:border-[var(--gold)] transition-colors">
            <div className="absolute inset-0 bg-gradient-to-b from-[rgba(212,175,55,0.05)] to-transparent pointer-events-none" />
            
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-serif font-bold text-[var(--gold)] text-lg flex items-center shadow-[var(--gold)]">
                <Brain className="w-5 h-5 mr-2" />
                ALCHEMIST AI
              </h2>
              <button 
                onClick={handleQuickAnalysis}
                disabled={isAnalyzing}
                className="bg-[rgba(212,175,55,0.1)] border border-[var(--gold)] text-[var(--gold)] p-1.5 rounded hover:bg-[var(--gold)] hover:text-black transition-colors disabled:opacity-50"
                title="Quick Analysis"
              >
                <RefreshCcw className={`w-4 h-4 ${isAnalyzing ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <div className="flex items-center justify-between mb-6">
              <div className="relative w-24 h-24 flex items-center justify-center">
                <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                  <circle cx="48" cy="48" r="40" fill="none" stroke="rgba(212,175,55,0.1)" strokeWidth="8" />
                  <motion.circle 
                    cx="48" cy="48" r="40" fill="none" stroke="var(--gold)" strokeWidth="8"
                    strokeDasharray="251.2"
                    initial={{ strokeDashoffset: 251.2 }}
                    animate={{ strokeDashoffset: 251.2 - (251.2 * confluenceScore) / 100 }}
                    transition={{ duration: 1.5, ease: "easeOut" }}
                  />
                </svg>
                <div className="text-3xl font-bold text-white">{confluenceScore}</div>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-xs text-[hsl(var(--muted-foreground))] uppercase tracking-wider mb-1">Bias</span>
                <div className="flex items-center text-green-500 font-bold text-xl">
                  <TrendingUp className="w-6 h-6 mr-1" />
                  BULLISH
                </div>
              </div>
            </div>

            <div className="flex-1 relative mb-6">
              <div className="absolute inset-0 overflow-y-auto pr-2 custom-scrollbar">
                <p className="text-sm text-[hsl(var(--muted-foreground))] leading-relaxed font-mono">
                  {analysisText}
                  <span className="animate-pulse">_</span>
                </p>
              </div>
            </div>

            <div className="space-y-2 shrink-0">
              <h3 className="text-xs font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider mb-2">Quick Signals</h3>
              <div className="flex items-center justify-between p-2 rounded bg-black/40 border border-[rgba(212,175,55,0.1)]">
                <span className="font-bold">EURUSD</span>
                <span className="text-red-500 flex items-center text-sm"><TrendingDown className="w-4 h-4 mr-1" /> SHORT</span>
                <span className="text-xs bg-[rgba(212,175,55,0.2)] text-[var(--gold)] px-2 py-0.5 rounded">HIGH</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-black/40 border border-[rgba(212,175,55,0.1)]">
                <span className="font-bold">GBPUSD</span>
                <span className="text-green-500 flex items-center text-sm"><TrendingUp className="w-4 h-4 mr-1" /> LONG</span>
                <span className="text-xs bg-[rgba(212,175,55,0.2)] text-[var(--gold)] px-2 py-0.5 rounded">MED</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 shrink-0">
        <div className="border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] p-4 group hover:border-[var(--gold)] transition-colors">
          <h3 className="text-sm font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider mb-3 flex items-center">
            <Radio className="w-4 h-4 mr-2" /> Stream Status
          </h3>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${streamIsLive ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.9)] animate-pulse' : 'bg-gray-600'}`} />
              <span className={`font-bold text-sm ${streamColor}`}>{streamLabel}</span>
            </div>
            {streamIsLive && (
              <span className="text-[10px] font-mono text-gray-500 bg-black/40 px-2 py-0.5 rounded">{getStreamResolution()}</span>
            )}
          </div>
          <div className="flex gap-3 mt-2">
            <div className="flex items-center gap-1.5 text-xs">
              <Camera className={`w-3.5 h-3.5 ${isActive ? 'text-green-400' : 'text-gray-600'}`} />
              <span className={isActive ? 'text-green-400' : 'text-gray-600'}>Camera {isActive ? 'ON' : 'OFF'}</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs">
              <Monitor className={`w-3.5 h-3.5 ${screenStream ? 'text-blue-400' : 'text-gray-600'}`} />
              <span className={screenStream ? 'text-blue-400' : 'text-gray-600'}>Screen {screenStream ? 'ON' : 'OFF'}</span>
            </div>
          </div>
          {!streamIsLive && (
            <p className="text-[10px] text-gray-600 mt-2">Go to Studio → Enable Camera to go live</p>
          )}
        </div>

        <div className="border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] p-4 group hover:border-[var(--gold)] transition-colors">
          <h3 className="text-sm font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider mb-4 flex items-center">
            <Clock className="w-4 h-4 mr-2" /> Market Sessions
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(MARKET_SESSIONS).map(([session, data]) => {
              const utcHour = new Date().getUTCHours();
              const active = session === 'sydney'
                ? utcHour >= 22 || utcHour < 7
                : utcHour >= data.start && utcHour < data.end;
              return (
                <div key={session} className="flex items-center justify-between text-sm">
                  <span className="capitalize">{session.replace(/([A-Z])/g, ' $1').trim()}</span>
                  <span className={`w-2 h-2 rounded-full ${active ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.8)]' : 'bg-gray-600'}`} />
                </div>
              );
            })}
          </div>
        </div>

        <div className="border border-[rgba(212,175,55,0.2)] rounded-lg bg-[hsl(var(--card))] p-4 group hover:border-[var(--gold)] transition-colors">
          <h3 className="text-sm font-semibold text-[hsl(var(--muted-foreground))] uppercase tracking-wider mb-4 flex items-center">
            <ShieldAlert className="w-4 h-4 mr-2" /> Risk Summary
          </h3>
          <div className="flex justify-between items-end">
            <div>
              <span className="text-xs text-[hsl(var(--muted-foreground))]">Daily P&L</span>
              <div className="text-2xl font-mono font-bold text-green-500">+$1,240.50</div>
            </div>
            <div className="text-right">
              <span className="text-xs text-[hsl(var(--muted-foreground))]">Risk Used</span>
              <div className="text-lg font-mono font-bold">0.5% / 2.0%</div>
            </div>
          </div>
          <div className="w-full h-1.5 bg-black rounded-full mt-3 overflow-hidden">
            <div className="h-full bg-[var(--gold)] w-1/4 rounded-full" />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
