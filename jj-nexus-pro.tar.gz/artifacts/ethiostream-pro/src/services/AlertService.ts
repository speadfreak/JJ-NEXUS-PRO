export interface JJNotification {
  id: string
  title: string
  body: string
  timestamp: number
  read: boolean
}

export class AlertService {
  private static priceAlerts: Map<string, { price: number; direction: 'above' | 'below'; pair: string }> = new Map()
  private static notificationsEnabled = false
  private static listeners: Array<(n: JJNotification) => void> = []

  static async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) return false
    const permission = await Notification.requestPermission()
    this.notificationsEnabled = permission === 'granted'
    return this.notificationsEnabled
  }

  static onNotification(cb: (n: JJNotification) => void) {
    this.listeners.push(cb)
    return () => { this.listeners = this.listeners.filter(l => l !== cb) }
  }

  static notify(title: string, body: string, icon = '/jj-trades-logo.jpg') {
    const notification: JJNotification = {
      id: `${Date.now()}-${Math.random()}`,
      title,
      body,
      timestamp: Date.now(),
      read: false,
    }

    if (this.notificationsEnabled && Notification.permission === 'granted') {
      new Notification(title, { body, icon })
    }

    window.dispatchEvent(new CustomEvent('jjnexus-notification', { detail: notification }))
    this.listeners.forEach(l => l(notification))
  }

  static addPriceAlert(pair: string, targetPrice: number, direction: 'above' | 'below') {
    const id = `${pair}-${direction}-${targetPrice}`
    this.priceAlerts.set(id, { price: targetPrice, direction, pair })
    this.notify('✅ Alert Set', `${pair} alert set for ${direction} $${targetPrice}`)
  }

  static checkPriceAlerts(currentPrices: Record<string, number>) {
    this.priceAlerts.forEach((alert, id) => {
      const currentPrice = currentPrices[alert.pair]
      if (!currentPrice) return
      const triggered =
        alert.direction === 'above' ? currentPrice >= alert.price : currentPrice <= alert.price
      if (triggered) {
        this.notify(
          `🚨 ${alert.pair} Alert Triggered!`,
          `Price is now ${alert.direction} $${alert.price}. Current: ${currentPrice.toFixed(5)}`
        )
        this.priceAlerts.delete(id)
      }
    })
  }

  static scheduleEventAlert(eventId: string, eventDate: string, eventTitle: string, minutesBefore: number) {
    const alertTime = new Date(eventDate).getTime() - minutesBefore * 60 * 1000
    const now = Date.now()
    if (alertTime <= now) return
    const delay = alertTime - now
    setTimeout(() => {
      this.notify(`⏰ Upcoming: ${eventTitle}`, `${eventTitle} starts in ${minutesBefore} minutes!`)
    }, delay)
  }

  static getPriceAlerts() {
    return Array.from(this.priceAlerts.entries()).map(([id, alert]) => ({ id, ...alert }))
  }

  static removePriceAlert(id: string) {
    this.priceAlerts.delete(id)
  }
}
