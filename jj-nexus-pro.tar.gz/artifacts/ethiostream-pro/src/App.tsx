import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { CameraProvider } from "@/context/CameraContext";

import { Preloader } from "@/components/Preloader";
import { Layout } from "@/components/Layout";
import NotFound from "@/pages/not-found";

import Dashboard from "@/pages/Dashboard";
import StreamingStudio from "@/pages/StreamingStudio";
import AlchemistAI from "@/pages/AlchemistAI";
import Watchlist from "@/pages/Watchlist";
import Journal from "@/pages/Journal";
import Settings from "@/pages/Settings";
import EconomicCalendar from "@/pages/EconomicCalendar";

const queryClient = new QueryClient();

const PageWrapper = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -20 }}
    transition={{ duration: 0.25 }}
    className="h-full"
  >
    {children}
  </motion.div>
);

function Router() {
  return (
    <Layout>
      <AnimatePresence mode="wait">
        <Switch>
          <Route path="/"><PageWrapper><Dashboard /></PageWrapper></Route>
          <Route path="/streaming"><PageWrapper><StreamingStudio /></PageWrapper></Route>
          <Route path="/alchemist"><PageWrapper><AlchemistAI /></PageWrapper></Route>
          <Route path="/watchlist"><PageWrapper><Watchlist /></PageWrapper></Route>
          <Route path="/journal"><PageWrapper><Journal /></PageWrapper></Route>
          <Route path="/calendar"><PageWrapper><EconomicCalendar /></PageWrapper></Route>
          <Route path="/settings"><PageWrapper><Settings /></PageWrapper></Route>
          <Route component={NotFound} />
        </Switch>
      </AnimatePresence>
    </Layout>
  );
}

function App() {
  const [loading, setLoading] = useState(true);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CameraProvider>
          <AnimatePresence mode="wait">
            {loading ? (
              <Preloader key="preloader" onComplete={() => setLoading(false)} />
            ) : (
              <motion.div
                key="main-app"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="h-screen w-full"
              >
                <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                  <Router />
                </WouterRouter>
              </motion.div>
            )}
          </AnimatePresence>
          <Toaster />
        </CameraProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
