import { createContext, useContext, useState, useEffect, ReactNode } from 'react'

interface CameraFilters {
  brightness: number
  contrast: number
  saturation: number
  zoom: number
  flipped: boolean
}

interface CameraContextType {
  stream: MediaStream | null
  screenStream: MediaStream | null
  devices: MediaDeviceInfo[]
  selectedDevice: string
  error: string
  filters: CameraFilters
  isActive: boolean
  startCamera: (deviceId?: string) => Promise<void>
  stopCamera: () => void
  startScreenShare: () => Promise<void>
  stopScreenShare: () => void
  setSelectedDevice: (id: string) => void
  setFilters: (f: Partial<CameraFilters>) => void
}

const CameraContext = createContext<CameraContextType | null>(null)

export function CameraProvider({ children }: { children: ReactNode }) {
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null)
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([])
  const [selectedDevice, setSelectedDevice] = useState<string>('')
  const [error, setError] = useState<string>('')
  const [isActive, setIsActive] = useState(false)
  const [filters, setFiltersState] = useState<CameraFilters>({
    brightness: 100, contrast: 100, saturation: 100, zoom: 1, flipped: false
  })

  useEffect(() => {
    navigator.mediaDevices.enumerateDevices()
      .then(all => setDevices(all.filter(d => d.kind === 'videoinput')))
      .catch(() => {})
  }, [])

  const startCamera = async (deviceId?: string) => {
    try {
      if (stream) stream.getTracks().forEach(t => t.stop())
      const constraints: MediaStreamConstraints = {
        video: deviceId
          ? { deviceId: { exact: deviceId }, width: 1280, height: 720 }
          : { width: 1280, height: 720 },
        audio: true
      }
      const s = await navigator.mediaDevices.getUserMedia(constraints)
      setStream(s)
      setIsActive(true)
      setError('')
      const all = await navigator.mediaDevices.enumerateDevices()
      setDevices(all.filter(d => d.kind === 'videoinput'))
    } catch (e: any) {
      setIsActive(false)
      if (e.name === 'NotAllowedError' || e.name === 'PermissionDeniedError') {
        setError('Camera permission denied. Please allow camera access in your browser settings and refresh.')
      } else if (e.name === 'NotFoundError') {
        setError('No camera detected. Please connect a camera and try again.')
      } else {
        setError(`Camera error: ${e.message}`)
      }
    }
  }

  const stopCamera = () => {
    stream?.getTracks().forEach(t => t.stop())
    setStream(null)
    setIsActive(false)
  }

  const startScreenShare = async () => {
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 30 } as any,
        audio: true
      })
      s.getVideoTracks()[0].onended = () => setScreenStream(null)
      setScreenStream(s)
    } catch (e: any) {
      if (e.name !== 'NotAllowedError') {
        setError(`Screen share error: ${e.message}`)
      }
    }
  }

  const stopScreenShare = () => {
    screenStream?.getTracks().forEach(t => t.stop())
    setScreenStream(null)
  }

  const setFilters = (f: Partial<CameraFilters>) => {
    setFiltersState(prev => ({ ...prev, ...f }))
  }

  return (
    <CameraContext.Provider value={{
      stream, screenStream, devices, selectedDevice, error, filters,
      isActive, startCamera, stopCamera, startScreenShare, stopScreenShare,
      setSelectedDevice, setFilters
    }}>
      {children}
    </CameraContext.Provider>
  )
}

export const useCamera = () => {
  const ctx = useContext(CameraContext)
  if (!ctx) throw new Error('useCamera must be used within CameraProvider')
  return ctx
}
