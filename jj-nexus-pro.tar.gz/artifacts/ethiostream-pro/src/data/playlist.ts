export interface Track {
  id: string
  title: string
  artist: string
  category: string
  youtubeId: string | null
  url?: string
}

export const PLAYLIST: Track[] = [
  // International
  { id: 'yt_pitbull', title: 'Options', artist: 'Pitbull ft. Stephen Marley', youtubeId: 'sV3AHDSk6Eg', category: 'International' },
  { id: 'yt_ego', title: 'Ego', artist: 'Beyoncé', youtubeId: 'It4j7bLRDisc', category: 'International' },
  { id: 'yt_lil_uzi', title: 'What You Say', artist: 'Lil Uzi Vert', youtubeId: 'WRiAiTCBJBM', category: 'International' },
  { id: 'yt_daylight', title: 'Daylight', artist: 'David Kushner', youtubeId: 'LHCob76kigA', category: 'International' },
  { id: 'yt_hope', title: 'Hope', artist: 'XXXTentacion', youtubeId: 'asqB4XUwCG0', category: 'International' },
  { id: 'yt_khalid', title: 'Young Dumb & Broke', artist: 'Khalid', youtubeId: 'GFSiNMxHHtk', category: 'International' },
  { id: 'yt_7years', title: '7 Years', artist: 'Lukas Graham', youtubeId: 'LTrjZjECLT4', category: 'International' },
  { id: 'yt_papaoute', title: 'Papaoute', artist: 'MHD', youtubeId: 'SxTCzEkqCdI', category: 'International' },
  // Ethiopian
  { id: 'yt_rophnan1', title: 'Neger', artist: 'Rophnan', youtubeId: '0mLuj_x_tGY', category: 'Ethiopian' },
  { id: 'yt_rophnan2', title: 'Sew Lemenged', artist: 'Rophnan', youtubeId: 'oHWtfhyDlVQ', category: 'Ethiopian' },
  { id: 'yt_teddy1', title: 'Tikur Sew', artist: 'Teddy Afro', youtubeId: 'GxKqHMU2VbI', category: 'Ethiopian' },
  { id: 'yt_teddy2', title: 'Ethiopia', artist: 'Teddy Afro', youtubeId: '7VGFbhLyGUA', category: 'Ethiopian' },
  { id: 'yt_kuku', title: 'Fikir Eske Mekabir', artist: 'Kuku Sebsebe', youtubeId: 'rVtXM3V4EVo', category: 'Ethiopian' },
  // Ambient (direct playback)
  { id: 'ambient1', title: 'Ambient Focus', artist: 'JJ NEXUS PRO', youtubeId: null, url: 'https://cdn.pixabay.com/audio/2022/10/16/audio_05f67b3be9.mp3', category: 'Ambient' },
  { id: 'ambient2', title: 'Deep Concentration', artist: 'JJ NEXUS PRO', youtubeId: null, url: 'https://cdn.pixabay.com/audio/2022/03/15/audio_c8e0a5c27e.mp3', category: 'Ambient' },
  { id: 'ambient3', title: 'Trading Flow', artist: 'JJ NEXUS PRO', youtubeId: null, url: 'https://cdn.pixabay.com/audio/2024/01/09/audio_f6e51b453c.mp3', category: 'Ambient' },
]

export const PLAYLIST_CATEGORIES = ['International', 'Ethiopian', 'Ambient'] as const
