import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, trades } from "@workspace/db";
import Anthropic from "@anthropic-ai/sdk";
import {
  CreateTradeBody,
  UpdateTradeParams,
  UpdateTradeBody,
  DeleteTradeParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function getClient(): Anthropic | null {
  const directKey = process.env.ANTHROPIC_API_KEY;
  if (directKey) return new Anthropic({ apiKey: directKey });
  const integrationKey = process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY;
  const integrationBaseUrl = process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL;
  if (integrationKey && integrationBaseUrl) return new Anthropic({ apiKey: integrationKey, baseURL: integrationBaseUrl });
  return null;
}

router.get("/trades", async (_req, res) => {
  const all = await db.select().from(trades).orderBy(trades.createdAt);
  res.json(all);
});

router.post("/trades", async (req, res) => {
  const body = CreateTradeBody.parse(req.body);
  const [created] = await db.insert(trades).values({
    pair: body.pair,
    direction: body.direction,
    entryPrice: body.entryPrice,
    stopLoss: body.stopLoss,
    takeProfit: body.takeProfit,
    strategy: body.strategy,
    notes: body.notes,
    status: body.status ?? "open",
  }).returning();
  res.status(201).json(created);
});

router.put("/trades/:id", async (req, res) => {
  const { id } = UpdateTradeParams.parse(req.params);
  const body = UpdateTradeBody.parse(req.body);

  const updateData: Partial<typeof trades.$inferInsert> = {};
  if (body.result !== undefined) updateData.result = body.result;
  if (body.pips !== undefined) updateData.pips = String(body.pips);
  if (body.riskReward !== undefined) updateData.riskReward = body.riskReward;
  if (body.status !== undefined) updateData.status = body.status;
  if (body.notes !== undefined) updateData.notes = body.notes;

  const [updated] = await db.update(trades).set(updateData).where(eq(trades.id, id)).returning();
  if (!updated) {
    res.status(404).json({ error: "Trade not found" });
    return;
  }
  res.json(updated);
});

router.delete("/trades/:id", async (req, res) => {
  const { id } = DeleteTradeParams.parse(req.params);
  const deleted = await db.delete(trades).where(eq(trades.id, id)).returning();
  if (!deleted.length) {
    res.status(404).json({ error: "Trade not found" });
    return;
  }
  res.status(204).send();
});

router.get("/stats", async (_req, res) => {
  const all = await db.select().from(trades);
  const closed = all.filter((t) => t.status === "closed" || t.result);

  const wins = closed.filter((t) => t.result === "win" || (t.pips !== null && Number(t.pips) > 0));
  const losses = closed.filter((t) => t.result === "loss" || (t.pips !== null && Number(t.pips) < 0));
  const breakEvens = closed.filter((t) => t.result === "be" || (t.pips !== null && Number(t.pips) === 0));

  const totalTrades = closed.length;
  const winRate = totalTrades > 0 ? (wins.length / totalTrades) * 100 : 0;
  const netPips = closed.reduce((sum, t) => sum + (t.pips !== null ? Number(t.pips) : 0), 0);

  const rrValues = closed
    .filter((t) => t.riskReward)
    .map((t) => {
      const parts = t.riskReward!.split(":");
      return parts.length === 2 ? Number(parts[1]) : 0;
    })
    .filter((v) => v > 0);

  const averageRR = rrValues.length > 0 ? rrValues.reduce((a, b) => a + b, 0) / rrValues.length : 0;

  res.json({
    totalTrades,
    winRate: Math.round(winRate * 10) / 10,
    averageRR: Math.round(averageRR * 10) / 10,
    netPips: Math.round(netPips * 10) / 10,
    winCount: wins.length,
    lossCount: losses.length,
    breakEvenCount: breakEvens.length,
  });
});

router.get("/insights", async (req, res) => {
  const all = await db.select().from(trades);

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const tradesSummary = all.map((t) => ({
    pair: t.pair,
    direction: t.direction,
    strategy: t.strategy,
    result: t.result,
    pips: t.pips,
    rr: t.riskReward,
    date: t.createdAt,
  }));

  const prompt = `You are an elite trading coach and performance analyst. Analyze this trader's journal data and provide 4-5 specific, actionable insights about their trading patterns, strengths, and areas for improvement.

Trade data: ${JSON.stringify(tradesSummary)}

Focus on:
- Win rate patterns by pair, strategy, and direction
- Risk management consistency
- Best and worst performing setups
- Time-based patterns if visible
- Specific recommendations to improve profitability

Be specific, professional, and encouraging. Use trader language.`;

  const client = getClient();

  if (!client) {
    res.write(`data: ${JSON.stringify({ content: "⚠️ Add your Anthropic API key in **Settings → API & Keys** to get AI-powered journal insights." })}\n\n`);
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
    return;
  }

  const stream = client.messages.stream({
    model: "claude-sonnet-4-6",
    max_tokens: 8192,
    messages: [{ role: "user", content: prompt }],
  });

  for await (const event of stream) {
    if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
      res.write(`data: ${JSON.stringify({ content: event.delta.text })}\n\n`);
    }
  }

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

export default router;
