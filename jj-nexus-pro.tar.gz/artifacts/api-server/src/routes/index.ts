import { Router, type IRouter } from "express";
import healthRouter from "./health";
import anthropicRouter from "./anthropic/index";
import analysisRouter from "./analysis/index";
import journalRouter from "./journal/index";
import proxyRouter from "./proxy/index";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/anthropic", anthropicRouter);
router.use("/analysis", analysisRouter);
router.use("/journal", journalRouter);
router.use("/proxy", proxyRouter);

export default router;
