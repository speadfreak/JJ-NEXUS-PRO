import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.get("/calendar", async (_req, res) => {
  try {
    const resp = await fetch("https://nfs.faireconomy.media/ff_calendar_thisweek.json", {
      headers: { "Accept": "application/json", "User-Agent": "JJNexusPro/2.0" }
    });
    if (!resp.ok) { res.status(resp.status).json({ error: "Calendar fetch failed" }); return; }
    const data = await resp.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/forex-rates", async (_req, res) => {
  try {
    const resp = await fetch("https://api.frankfurter.app/latest?from=USD&to=EUR,GBP,JPY,CHF,AUD,NZD,CAD", {
      headers: { "Accept": "application/json" }
    });
    if (!resp.ok) { res.status(resp.status).json({ error: "Forex rate fetch failed" }); return; }
    const data = await resp.json();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
