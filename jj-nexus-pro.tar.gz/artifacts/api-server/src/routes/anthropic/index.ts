import { Router, type IRouter } from "express";
import Anthropic from "@anthropic-ai/sdk";
import { eq } from "drizzle-orm";
import { db, conversations, messages } from "@workspace/db";
import {
  CreateAnthropicConversationBody,
  GetAnthropicConversationParams,
  DeleteAnthropicConversationParams,
  ListAnthropicMessagesParams,
  SendAnthropicMessageParams,
  SendAnthropicMessageBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

function getClient(): { client: Anthropic; hasWebSearch: boolean } | null {
  const directKey = process.env.ANTHROPIC_API_KEY;
  if (directKey) {
    return {
      client: new Anthropic({ apiKey: directKey, defaultHeaders: { "anthropic-beta": "web-search-2025-03-05" } }),
      hasWebSearch: true,
    };
  }
  const integrationKey = process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY;
  const integrationBaseUrl = process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL;
  if (integrationKey && integrationBaseUrl) {
    return {
      client: new Anthropic({ apiKey: integrationKey, baseURL: integrationBaseUrl }),
      hasWebSearch: false,
    };
  }
  return null;
}

const TODAY = new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });

const WEB_SEARCH_TOOL: Anthropic.Tool = {
  type: "web_search_20250305" as any,
  name: "web_search",
} as any;

router.get("/conversations", async (_req, res) => {
  const all = await db.select().from(conversations).orderBy(conversations.createdAt);
  res.json(all);
});

router.post("/conversations", async (req, res) => {
  const body = CreateAnthropicConversationBody.parse(req.body);
  const [created] = await db.insert(conversations).values({ title: body.title }).returning();
  res.status(201).json(created);
});

router.get("/conversations/:id", async (req, res) => {
  const { id } = GetAnthropicConversationParams.parse(req.params);
  const conv = await db.query.conversations.findFirst({
    where: eq(conversations.id, id),
    with: { messages: { orderBy: (m: any, { asc }: any) => [asc(m.createdAt)] } },
  });
  if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }
  res.json(conv);
});

router.delete("/conversations/:id", async (req, res) => {
  const { id } = DeleteAnthropicConversationParams.parse(req.params);
  const deleted = await db.delete(conversations).where(eq(conversations.id, id)).returning();
  if (!deleted.length) { res.status(404).json({ error: "Conversation not found" }); return; }
  res.status(204).send();
});

router.get("/conversations/:id/messages", async (req, res) => {
  const { id } = ListAnthropicMessagesParams.parse(req.params);
  const msgs = await db.select().from(messages).where(eq(messages.conversationId, id));
  res.json(msgs);
});

router.post("/conversations/:id/messages", async (req, res) => {
  const { id } = SendAnthropicMessageParams.parse(req.params);
  const body = SendAnthropicMessageBody.parse(req.body);
  const cfg = getClient();

  const conv = await db.query.conversations.findFirst({ where: eq(conversations.id, id) });
  if (!conv) { res.status(404).json({ error: "Conversation not found" }); return; }

  await db.insert(messages).values({ conversationId: id, role: "user", content: body.content });

  const allMessages = await db.select().from(messages).where(eq(messages.conversationId, id));
  const chatMessages = allMessages.map((m) => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  if (!cfg) {
    res.write(`data: ${JSON.stringify({ content: "⚠️ No AI configured. Replit integration env vars not set — please check integration status." })}\n\n`);
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
    res.end();
    return;
  }

  const { client, hasWebSearch } = cfg;

  const systemPrompt = hasWebSearch
    ? `You are Alchemist AI, an elite Forex trading assistant for JJ Nexus Pro. You specialize in Smart Money Concepts (SMC), ICT methodology, technical analysis, and market structure. When asked about prices or market data, use the web_search tool to find CURRENT live data — never use outdated training data. Today's date: ${TODAY}. Provide clear, confident, professional trading insights. Keep responses concise and actionable.`
    : `You are Alchemist AI, an elite Forex trading assistant for JJ Nexus Pro. You specialize in Smart Money Concepts (SMC), ICT methodology, technical analysis, and market structure. Today's date: ${TODAY}. Provide clear, confident, professional trading insights based on your knowledge. For live prices, advise users to check TradingView. Keep responses concise and actionable.`;

  let fullResponse = "";

  try {
    const stream = await client.messages.stream({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      system: systemPrompt,
      tools: hasWebSearch ? [WEB_SEARCH_TOOL] : undefined,
      messages: chatMessages,
    });

    for await (const event of stream) {
      if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
        fullResponse += event.delta.text;
        res.write(`data: ${JSON.stringify({ content: event.delta.text })}\n\n`);
      }
    }

    await db.insert(messages).values({ conversationId: id, role: "assistant", content: fullResponse });
  } catch (err: any) {
    res.write(`data: ${JSON.stringify({ content: `Error: ${err.message}` })}\n\n`);
  }

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

export default router;
